# ScholarDesk · 本地优先的 AI 科研助手

> 你自己的"学术版 Codex"：文献检索、PDF 知识库问答、保真对照翻译、综述写作，
> **算力由你自己接** —— 换一个 base_url 就换一家模型供应商，不被任何会员套餐绑定。

和切问学术（QieWen / WisPaper）这类产品是同一类工作流的**自建版本**：
它不破解任何软件，也不动别人的付费校验；它把你真正需要的四个环节做在自己电脑上，
模型调用直连你选择的供应商，文献、译文、用量全部落在本地磁盘。

---

## 一、三分钟跑起来

前置：装好 [Node.js](https://nodejs.org/) 20 以上。

```bash
cd scholar-desk
npm install      # 装 Electron 与 PDF 解析库
npm start        # 启动客户端
```

第一次启动会停在「模型与设置」：

1. **供应商** 选一家（推荐先用 DeepSeek，便宜且中文好）
2. **API Key** 填进去（各平台控制台新建即可，Key 只存在本机，用系统级加密存储）
3. 点 **测试连接** → 显示"连接成功"就能用了

> 想先看看效果不花钱？装 [Ollama](https://ollama.com/) 跑本地模型，
> 供应商选「本地 Ollama」，base_url 填 `http://localhost:11434/v1`，价格为 0。

---

## 二、打包成 Windows 的 exe

产出两个文件，都在 `dist/` 下：

| 产物 | 说明 |
|---|---|
| `ScholarDesk-0.1.0-x64-Setup.exe` | **安装版**：标准安装向导（简体中文），可选安装目录，建桌面与开始菜单快捷方式，可分发给别人 |
| `ScholarDesk-0.1.0-x64-便携版.exe` | **免安装版**：双击即用，不写注册表，适合放 U 盘或直接丢给同学 |

### 方式 A：本机一键打包（推荐）

在 Windows 上装好 Node.js 20+，然后**双击 `build-windows.bat`**，或在 PowerShell 里：

```powershell
.\build-windows.bat
```

脚本会依次做：装依赖 → 生成图标 → 跑自测 → 打包 → 自动打开 `dist` 目录。
首次打包需要下载 Electron 二进制（约 100 MB），耗时几分钟；`.npmrc` 已把下载源指向国内镜像。

也可以手动分步执行：

```bash
npm install
npm run dist:win      # 安装版 + 便携版
npm run pack:win      # 只生成未压缩目录，用于快速验证
```

### 方式 B：用 GitHub Actions 云构建（本机不用装环境）

仓库推到 GitHub 后：

- **手动触发**：Actions → 「构建 Windows 安装包」→ Run workflow
- **打 tag 触发**：`git tag v0.1.0 && git push origin v0.1.0`

云端 Windows 机器会自动打包，产物在 Actions 页面下载；打 tag 时还会自动挂到 Release 上。

### 打包前自检

```bash
node scripts/check-build-config.js
```

会检查入口文件、图标（含 256×256）、NSIS 配置、依赖与 asar 设置是否都对，避免打完包才发现缺东西。

### 三个打包相关的注意点

**1. `asar` 必须关掉（已配置为 `false`，不要改）**
`pdfjs-dist` 是 ESM，通过动态 `import()` 加载 `.mjs`；Node 的 ESM loader 不认识 asar 协议，
一旦打进 `app.asar`，PDF 解析会直接报「找不到模块」。关掉 asar 后文件散落在安装目录，NSIS 会压缩，体积差别不大。

**2. 首次运行会被 SmartScreen 拦一下**
未签名的 exe 会提示「Windows 已保护你的电脑」，点 **更多信息 → 仍要运行** 即可。
要彻底消除需要购买代码签名证书（OV/EV，年费几百到几千元），个人自用不建议为此花钱。

**3. 杀毒软件误报**
Electron 应用常被误报。自建自用无需理会；分发给他人的话，用方式 B 生成的 Release 链接比 exe 附件更省事。

### 体积与运行时

安装后约 200–260 MB（含完整 Chromium + Node 运行时），这是 Electron 的固有开销，无法再压。
运行时不依赖用户装 Python 或任何编译器。

---

## 三、功能地图

| 模块 | 做什么 | 解决什么痛点 |
|---|---|---|
| **知识库** | 拖入 PDF → 自动切出带**章节 + 页码**的片段 → 本地索引 | 读过的论文能随时被"想起来"，不是躺在文件夹里 |
| **文献问答** | 跨文档提问「这几篇在 Dice 上谁更强」 | 答案只来自你的原文，每条论断带证据编号可回原文核对 |
| **文献检索** | 聚合 arXiv / OpenAlex / Crossref / Semantic Scholar | 全是免费公开接口，不依赖任何付费数据库账号 |
| **对照翻译** | 段落级中英对照，**公式、图表编号、参考文献原样保留** | 通用翻译器把论文翻成乱码的问题 |
| **综述写作** | 检索证据 → 生成大纲 → 逐节撰写 → 附证据清单 | 开题、Related Work、基金立项的初稿体力活 |
| **写作辅助** | 润色 / 摘要 / Methods 规范化 / 审稿回复 | 学术汉语与英美学术写作的表达问题 |
| **用量统计** | 每次调用的 token 与折算成本，按供应商/功能/日期 | 花了多少钱自己看得见，而不是被动充值 |

---

## 四、算力：想换就换

统一走 **OpenAI 兼容协议**（`/chat/completions`、`/embeddings`），所以换供应商 = 改两个字段：

| 供应商 | base_url | 参考模型 |
|---|---|---|
| DeepSeek | `https://api.deepseek.com/v1` | `deepseek-chat` |
| 通义千问（百炼） | `https://dashscope.aliyuncs.com/compatible-mode/v1` | `qwen-plus` |
| Kimi（Moonshot） | `https://api.moonshot.cn/v1` | `moonshot-v1-32k` |
| 智谱 GLM | `https://open.bigmodel.cn/api/paas/v4` | `glm-4-flash` |
| 硅基流动 | `https://api.siliconflow.cn/v1` | `deepseek-ai/DeepSeek-V3` |
| OpenAI | `https://api.openai.com/v1` | `gpt-4o-mini` |
| 本地 Ollama | `http://localhost:11434/v1` | `qwen2.5:14b` |
| 自定义 | 任意 OpenAI 兼容端点（vLLM / LM Studio / 公司内网网关） | 自填 |

界面里选「自定义」即可接任何兼容端点；每家的**单价可以在设置里改**，只用于本地成本估算。

---

## 五、几个关键设计（为什么这么写）

**① 检索不用 SQLite FTS5**
`better-sqlite3` 要 node-gyp 本地编译，很多机器上装不上。
个人知识库（几百篇 PDF、数万片段）用纯 JS 的 **BM25 倒排索引**完全够用，秒级构建、零编译依赖。
中文按 bigram 切分，中英混排也能召回；可选开启向量语义重排（需要供应商支持 embeddings）。

**② PDF 靠文字坐标重建行与段落**
pdf.js 吐出来的是一堆带坐标的碎片，**没有换行**。
如果直接按字符串处理，整页会变成一坨，切出来的片段毫无结构。
这里按 y 坐标聚行、按 x 排序拼接、按行间距推断段落，才有了后面的"章节归属 + 页码溯源"。

**③ 证据锚点机制压制幻觉**
检索到的片段编号成 `[1]..[n]`，模型**只能引用这些编号**，编不出编号就会露馅。
输出时编号还原成"文献名 + 章节 + 页码 + 原文明摘"，你可以逐条点开核对。
系统提示里写死了"找不到就说未找到"——综述可以写得不好，但不能假。

**④ 翻译保真的三道防线**
公式/纯符号段落在解析阶段就标记为**不翻译**（原样搬运）；
分批翻译时携带并持续累积**术语表**，保证前后一致；
段落级**缓存**，同一段只翻一次，重翻和增量更新都不重复花钱。

**⑤ 数据边界**
知识库、译文缓存、用量、配置全部在 `app.getPath('userData')`；
API Key 用 Electron `safeStorage` 系统级加密；请求直连供应商，没有中间服务器。
未发表的敏感数据建议配合本地模型（Ollama）使用。

---

## 六、已知限制（实话实说）

- **扫描件 PDF 提取不到文字**：需要先用 OCR，或用「导入文本」粘贴全文。
- **未嵌入的中日韩 CID 字体**可能提取为空：可用环境变量 `SCHOLARDESK_PDF_ENGINE=pdfparse` 换备用引擎试试。
- **公开检索接口受网络影响**：arXiv / OpenAlex / Crossref 在国内可能需要代理；单个源失败不影响其他源，界面会提示哪个源挂了。
- **翻译保留的是"文本层保真"**，不是像素级排版还原（公式、编号、参考文献保留；复杂双栏表格请以原文为准）。
- **向量重排**需要供应商提供 embeddings 接口，且会多花 token，默认关闭。
- 综述与写作输出是**初稿**，学术发表前必须人工逐条核对引用与数据。

---

## 七、目录结构

```
src/
├── main/
│   ├── index.js         Electron 主进程入口
│   ├── ipc.js           所有界面的调用入口（频道式 API）
│   ├── providers.js     ★ 模型适配层：多家 OpenAI 兼容，可切换
│   ├── library.js       知识库：入库 / 检索 / 出处
│   ├── bm25.js          零依赖倒排索引 + 中英混排分词
│   ├── pdf.js           PDF 解析、坐标重建、学术结构切分
│   ├── translate.js     保真对照翻译 + 术语表 + 缓存
│   ├── survey.js        问答 / 综述 / 写作辅助（证据锚点）
│   ├── search/          学术检索：arXiv / OpenAlex / Crossref / S2 + 导出
│   ├── store.js         配置与凭据（系统加密）
│   └── usage.js         用量与成本统计
├── renderer/            界面（原生 HTML/CSS/JS，无打包步骤）
├── shared/prompts.js    学术提示词
└── preload.js           安全桥
scripts/
├── smoke-test.js           核心逻辑自测（npm test，不联网、不需要 Electron）
├── check-build-config.js   打包前配置自检
└── make-icon.py            生成多尺寸应用图标
build/                      图标与安装向导头图（打包资源）
build-windows.bat           Windows 一键打包脚本
.github/workflows/          云端 Windows 自动构建
```

## 八、自测

```bash
npm test
```

34 项覆盖：分词与 BM25、真实 PDF 的章节识别、知识库检索与出处、
翻译响应解析（含脏输入兜底）、四家检索 API 的响应解析与去重、BibTeX/GB-T 7714 导出、
模型适配层的流式与非流式调用、用量折算。

## 九、下一步可以长成什么样

- Zotero 单向同步（`better-bibtex` 或本地 sqlite 直读）
- LaTeX / Word 导出与期刊模板
- MCP 工具接入（PubMed、UniProt、ChEMBL 等专业库）
- 实验复现 Agent（配环境 → 跑代码 → 出图表，本地或 SSH 到服务器 GPU）

---

### 许可与提醒

本项目为个人学习与科研辅助用途。使用各家模型时请遵守对应平台的服务条款；
AI 生成的综述、译文与结论只能作为初稿，学术成果的完整性与真实性由作者本人负责。
