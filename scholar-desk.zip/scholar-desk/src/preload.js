'use strict';

const { contextBridge, ipcRenderer } = require('electron');

/**
 * 安全桥：界面只能拿到这两个方法，拿不到 ipcRenderer 本身，更碰不到 Node。
 */
contextBridge.exposeInMainWorld('api', {
  /** 调用主进程频道，返回 {ok:true,data} 或 {ok:false,error} */
  invoke: (channel, payload) => ipcRenderer.invoke(channel, payload),
  /** 订阅推送（流式输出、任务进度），返回取消订阅函数 */
  on: (channel, cb) => {
    const listener = (_event, ...args) => cb(...args);
    ipcRenderer.on(channel, listener);
    return () => ipcRenderer.removeListener(channel, listener);
  },
  /** 生成本地唯一的流/任务 id */
  newId: (prefix = 'id') => `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
});
