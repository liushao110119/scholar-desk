'use strict';
/* ScholarDesk 界面逻辑（原生 JS，无打包步骤） */

const api = window.api;
const $ = (s) => document.querySelector(s);
const mainEl = () => $('#main');

const S = {
  view: 'library',
  config: null,
  presets: [],
  hasKey: {},
  docs: [],
  stats: { docs: 0, chunks: 0, chars: 0 },
  selectedDocId: null,
  evidences: [],
  searchResults: [],
  lastSurvey: null,
  lastTranslate: null,
  streamId: null,
  streamBuf: '',
  jobId: null,
};

// ------------------------------------------------------------------ 工具

async function call(channel, payload) {
  const r = await api.invoke(channel, payload);
  if (!r || !r.ok) throw new Error((r && r.error) || '调用失败');
  return r.data;
}

function esc(s) {
  return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

let toastTimer = null;
function toast(msg, isErr) {
  const t = $('#toast');
  t.textContent = msg;
  t.className = 'toast' + (isErr ? ' err' : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.add('hidden'), isErr ? 5200 : 2600);
}

/** 极简 Markdown 渲染 + 把 [n] 变成可点证据角标 */
function renderRich(text) {
  const withCites = esc(text).replace(/\[(\d+)\]/g, '<sup class="cite" data-n="$1">[$1]</sup>');
  return withCites
    .split(/\n{2,}/)
    .map((block) => {
      if (/^#{1,4}\s/.test(block)) {
        const m = block.match(/^(#{1,4})\s+(.*)$/s);
        return `<h4 style="margin:14px 0 6px;font-size:14.5px">${m[2]}</h4>`;
      }
      if (/^[-*]\s/m.test(block)) {
        const items = block.split(/\n/).filter(Boolean).map((l) => `<li>${l.replace(/^[-*]\s/, '')}</li>`).join('');
        return `<ul style="margin:6px 0 6px 18px;padding:0">${items}</ul>`;
      }
      return `<p style="margin:0 0 8px">${block.replace(/\n/g, '<br>')}</p>`;
    })
    .join('');
}

function progressHtml(id) {
  return `<div class="progress" id="${id}"><i></i></div><div class="phase" id="${id}-phase"></div>`;
}

function setProgress(id, current, total, phase) {
  const bar = document.getElementById(id);
  if (!bar) return;
  const pct = total ? Math.min(100, Math.round((current / total) * 100)) : 0;
  bar.querySelector('i').style.width = pct + '%';
  const ph = document.getElementById(id + '-phase');
  if (ph) ph.textContent = phase ? `${phase}（${current}/${total}）` : '';
}

// ------------------------------------------------------------------ 侧栏

async function refreshLibrary() {
  const d = await call('library:list');
  S.docs = d.docs;
  S.stats = d.stats;
  renderDocList();
  if (S.view === 'library') renderLibTable();
}

function renderDocList() {
  const box = $('#doc-list');
  if (!S.docs.length) {
    box.innerHTML = '<div class="hint" style="padding:8px 6px">还没有文献，点 ＋ 导入 PDF</div>';
  } else {
    box.innerHTML = S.docs
      .map(
        (d) => `<div class="doc-item ${d.id === S.selectedDocId ? 'sel' : ''}" data-doc="${d.id}" title="${esc(d.title)}">
        <span class="dt">${esc(d.title)}</span>
        <span class="dm">${d.year ? d.year + ' · ' : ''}${d.numpages || 1} 页 · ${d.chunkCount} 片段</span>
      </div>`
      )
      .join('');
  }
  $('#lib-stats').textContent = `${S.stats.docs} 篇 · ${S.stats.chunks} 片段 · ${(S.stats.chars / 10000).toFixed(1)} 万字`;
}

function renderProviderBadge() {
  const badge = $('#provider-badge');
  if (!badge) return;
  const id = S.config && S.config.provider;
  const p = S.presets.find((x) => x.id === id);
  const cfg = id && S.config.providers[id];
  if (!id || !p) {
    badge.textContent = '未配置模型';
    badge.className = 'badge warn';
    return;
  }
  const hasKey = S.hasKey[id];
  badge.textContent = `${p.label} · ${cfg?.model || '未选模型'}${hasKey ? '' : ' · 缺 Key'}`;
  badge.className = 'badge' + (hasKey ? '' : ' warn');
}

async function loadConfig() {
  const d = await call('config:get');
  S.config = d.config;
  S.presets = d.presets;
  S.hasKey = d.hasKey;
  renderProviderBadge();
}

// ------------------------------------------------------------------ 视图

function setView(v) {
  S.view = v;
  document.querySelectorAll('.nav-item').forEach((b) => b.classList.toggle('active', b.dataset.view === v));
  const renderers = {
    library: viewLibrary,
    search: viewSearch,
    qa: viewQA,
    translate: viewTranslate,
    survey: viewSurvey,
    write: viewWrite,
    settings: viewSettings,
  };
  mainEl().innerHTML = renderers[v]();
  if (v === 'library') refreshLibrary();
  if (v === 'settings') loadUsage();
  if (v === 'qa' || v === 'survey' || v === 'translate') {
    $('#evidence').classList.add('hidden');
  }
}

function head(title, desc) {
  return `<div class="view-head"><h1>${title}</h1></div><p class="view-desc">${desc}</p>`;
}

// ---- 知识库
function viewLibrary() {
  return (
    head('知识库', 'PDF 解析后切成带章节与页码的片段，全部索引在你本机，不上传任何服务器。') +
    `<div class="card">
      <div class="row">
        <button class="btn primary" data-act="import">导入 PDF</button>
        <button class="btn" data-act="import-text">粘贴/导入文本</button>
        <button class="btn ghost" data-act="reveal-dir">打开数据目录</button>
      </div>
      <div class="hint" style="margin-top:10px">
        导入后自动识别标题、章节、公式与参考文献；扫描件请先 OCR，或用「导入文本」粘贴全文。
      </div>
    </div>
    <div class="card"><h3>已入库文献</h3><div id="lib-table"></div></div>`
  );
}

function renderLibTable() {
  const box = document.getElementById('lib-table');
  if (!box) return;
  if (!S.docs.length) {
    box.innerHTML = '<div class="empty">还没有文献。点击上方「导入 PDF」开始。</div>';
    return;
  }
  box.innerHTML = S.docs
    .map(
      (d) => `<div class="result">
      <div class="row" style="justify-content:space-between">
        <div style="min-width:0">
          <div class="rt">${esc(d.title)}</div>
          <div class="ra">${esc(d.authors || '作者未识别')}${d.year ? ' · ' + d.year : ''} · ${d.numpages} 页 · ${d.chunkCount} 片段 · ${d.source === 'pdf' ? 'PDF' : '文本'}</div>
        </div>
        <div class="row">
          <button class="btn sm" data-act="peek" data-doc="${d.id}">看片段</button>
          <button class="btn sm" data-act="to-translate" data-doc="${d.id}">翻译</button>
          <button class="btn sm" data-act="reveal" data-doc="${d.id}">定位文件</button>
          <button class="btn sm" data-act="del" data-doc="${d.id}">删除</button>
        </div>
      </div>
    </div>`
    )
    .join('');
}

// ---- 文献检索
function viewSearch() {
  return (
    head('文献检索', '聚合 arXiv / OpenAlex / Crossref / Semantic Scholar 的免费公开接口，无需付费账号。') +
    `<div class="card">
      <div class="row">
        <input type="text" id="q" class="grow" placeholder="用自然语言或关键词描述你要找的研究，例如：medical image segmentation transformer" />
        <button class="btn primary" data-act="do-search">检索</button>
      </div>
      <div class="row" style="margin-top:10px">
        <label class="chk"><input type="checkbox" class="src" value="arxiv" checked /> arXiv</label>
        <label class="chk"><input type="checkbox" class="src" value="openalex" checked /> OpenAlex</label>
        <label class="chk"><input type="checkbox" class="src" value="crossref" checked /> Crossref</label>
        <label class="chk"><input type="checkbox" class="src" value="semanticscholar" /> Semantic Scholar</label>
        <span style="width:8px"></span>
        <input type="number" id="yf" placeholder="起始年" style="width:92px" />
        <input type="number" id="yt" placeholder="截止年" style="width:92px" />
      </div>
    </div>
    <div class="card">
      <div class="row" style="justify-content:space-between;margin-bottom:6px">
        <h3 style="margin:0">结果 <span class="hint" id="search-count"></span></h3>
        <div class="row" id="search-actions" style="display:none">
          <button class="btn sm" data-act="exp-bib">导出 BibTeX</button>
          <button class="btn sm" data-act="exp-gb">导出 GB/T 7714</button>
        </div>
      </div>
      <div id="search-results"><div class="empty">输入检索词开始。检索走公开接口，国内网络若不通请检查代理设置。</div></div>
    </div>`
  );
}

async function doSearch() {
  const q = $('#q').value.trim();
  if (!q) return toast('请输入检索词');
  const sources = [...document.querySelectorAll('.src:checked')].map((x) => x.value);
  $('#search-results').innerHTML = '<div class="empty">检索中…</div>';
  try {
    const d = await call('search:literature', {
      query: q,
      sources,
      limit: 20,
      yearFrom: Number($('#yf').value) || 0,
      yearTo: Number($('#yt').value) || 0,
    });
    S.searchResults = d.items || [];
    $('#search-count').textContent = `共 ${S.searchResults.length} 条${d.errors && d.errors.length ? '（部分数据源失败：' + d.errors.map((e) => e.source).join('、') + '）' : ''}`;
    $('#search-actions').style.display = S.searchResults.length ? 'flex' : 'none';
    $('#search-results').innerHTML = S.searchResults.length
      ? S.searchResults
          .map(
            (p, i) => `<div class="result">
          <div class="rt">${esc(p.title)}</div>
          <div class="ra">${esc((p.authors || []).slice(0, 6).join(', '))}${p.authors?.length > 6 ? ' 等' : ''}${p.year ? ' · ' + p.year : ''}${p.venue ? ' · ' + esc(p.venue) : ''}</div>
          ${p.abstract ? `<div class="rabs">${esc(p.abstract.slice(0, 260))}${p.abstract.length > 260 ? '…' : ''}</div>` : ''}
          <div class="tags">
            <span class="tag src">${esc(p.sources ? p.sources.join('/') : p.source)}</span>
            ${p.citationCount != null ? `<span class="tag">被引 ${p.citationCount}</span>` : ''}
            ${p.pdfUrl ? `<a class="tag open" href="#" data-act="open" data-url="${esc(p.pdfUrl)}">PDF</a>` : ''}
            ${p.url ? `<a class="tag open" href="#" data-act="open" data-url="${esc(p.url)}">原文页</a>` : ''}
            ${p.doi ? `<span class="tag">DOI ${esc(p.doi)}</span>` : ''}
          </div>
        </div>`
          )
          .join('')
      : '<div class="empty">没有找到结果。换个关键词，或勾选更多数据源试试。</div>';
  } catch (e) {
    $('#search-results').innerHTML = `<div class="empty">${esc(e.message)}</div>`;
  }
}

// ---- 问答
function viewQA() {
  const opts = S.docs.map((d) => `<option value="${d.id}">${esc(d.title)}</option>`).join('');
  return (
    head('文献问答', '只依据你知识库里的原文回答，每条论断带证据编号，可逐条回原文核对。') +
    `<div class="card">
      <div class="row">
        <select id="qa-scope" style="max-width:340px">
          <option value="">全部文献</option>
          ${opts}
        </select>
        <span class="hint">限定范围可以提高精度</span>
      </div>
      <textarea id="qa-q" rows="3" style="margin-top:10px" placeholder="例如：这几篇在 Dice 系数上谁更强？各自用了什么数据集？"></textarea>
      <div class="row" style="margin-top:10px">
        <button class="btn primary" data-act="ask">提问</button>
        <button class="btn ghost" data-act="stop-qa">停止</button>
      </div>
    </div>
    <div class="card"><h3>回答</h3><div id="qa-out" class="answer"><span class="hint">在这里显示带证据编号的回答。点右上角「证据与出处」核对原文。</span></div></div>`
  );
}

async function askQuestion() {
  const q = $('#qa-q').value.trim();
  if (!q) return toast('请输入问题');
  const scope = $('#qa-scope').value;
  const out = $('#qa-out');
  S.streamId = api.newId('s');
  S.streamBuf = '';
  out.className = 'answer streaming';
  out.innerHTML = '';
  $('#evidence').classList.remove('hidden');
  $('#ev-body').innerHTML = '<div class="hint">检索证据中…</div>';
  try {
    const d = await call('qa:ask', { question: q, docIds: scope ? [scope] : null, streamId: S.streamId });
    S.evidences = d.evidence || [];
    out.classList.remove('streaming');
    out.innerHTML = renderRich(d.answer) || '<span class="hint">（空回答）</span>';
    renderEvidence(S.evidences);
    if (!S.evidences.length) toast('没有检索到证据，回答可能不可靠', true);
  } catch (e) {
    out.classList.remove('streaming');
    out.innerHTML = `<span style="color:var(--red)">${esc(e.message)}</span>`;
  }
}

function renderEvidence(list) {
  const box = $('#ev-body');
  if (!list || !list.length) {
    box.innerHTML = '<div class="hint">没有证据片段。</div>';
    return;
  }
  box.innerHTML = list
    .map(
      (e) => `<div class="ev-item">
      <div class="eh"><span class="en">${e.n}</span>${esc(e.title)}${e.year ? ' · ' + e.year : ''}</div>
      <div class="eh">${esc(e.section || '正文')} · 第 ${e.page || '?'} 页 · 相关度 ${e.score}</div>
      <div class="et">${esc(e.excerpt)}</div>
    </div>`
    )
    .join('');
}

// ---- 翻译
function viewTranslate() {
  const opts = S.docs.map((d) => `<option value="${d.id}">${esc(d.title)}</option>`).join('');
  return (
    head('对照翻译', '段落级中英对照，公式、图表编号与参考文献原样保留；术语表跨段落保持一致，译过的段落自动缓存。') +
    `<div class="card">
      <div class="row">
        <select id="tr-doc" style="max-width:420px"><option value="">选择文献…</option>${opts}</select>
        <select id="tr-lang" style="width:130px">
          <option value="zh">译为简体中文</option>
          <option value="en">译为 English</option>
        </select>
        <button class="btn primary" data-act="do-translate">开始翻译</button>
        <button class="btn ghost" data-act="stop-translate">停止</button>
      </div>
      <div class="hint" style="margin-top:8px">长文建议分批跑；中断后再点翻译会自动跳过已完成的段落（缓存命中不花钱）。</div>
      ${progressHtml('tr-prog')}
    </div>
    <div class="card">
      <div class="row" style="justify-content:space-between;margin-bottom:8px">
        <h3 style="margin:0">对照结果</h3>
        <div class="row" id="tr-actions" style="display:none">
          <button class="btn sm" data-act="exp-md">导出 Markdown</button>
          <button class="btn sm" data-act="exp-html">导出对照网页</button>
        </div>
      </div>
      <div id="tr-out"><div class="empty">选择文献后开始翻译。</div></div>
    </div>`
  );
}

async function doTranslate() {
  const docId = $('#tr-doc').value;
  if (!docId) return toast('请选择文献');
  S.jobId = api.newId('job');
  $('#tr-out').innerHTML = '<div class="empty">正在提取原文并调用模型…</div>';
  try {
    const d = await call('translate:run', { docId, targetLang: $('#tr-lang').value, jobId: S.jobId });
    S.lastTranslate = d;
    const rows = d.segments
      .filter((s) => s.kind !== 'heading')
      .map(
        (s) => `<div class="bi-row">
        <div><div class="bi-head">原文 · p.${s.page} · ${esc(s.section)}</div><div class="bi-src">${esc(s.text)}</div></div>
        <div><div class="bi-head">译文${s.cached ? ' · 缓存' : ''}${s.skipped ? ' · 原文保留（公式/参考文献）' : ''}</div><div class="bi-dst">${s.translated ? esc(s.translated) : '<span class="hint">（未翻译）</span>'}</div></div>
      </div>`
      )
      .join('');
    $('#tr-out').innerHTML = rows || '<div class="empty">没有可翻译的段落。</div>';
    $('#tr-actions').style.display = 'flex';
    if (d.errors && d.errors.length) toast(`有 ${d.errors.length} 处未成功翻译`, true);
    else toast('翻译完成');
  } catch (e) {
    $('#tr-out').innerHTML = `<div class="empty" style="color:var(--red)">${esc(e.message)}</div>`;
  }
}

// ---- 综述
function viewSurvey() {
  return (
    head('综述写作', '先检索证据、生成大纲，再逐节撰写；每句话都能回溯到原文片段。生成结果是初稿，必须人工核对后使用。') +
    `<div class="card">
      <div class="row">
        <input type="text" id="sv-topic" class="grow" placeholder="综述主题，例如：医学图像分割中的 Transformer 方法综述" />
        <button class="btn primary" data-act="do-survey">生成</button>
        <button class="btn ghost" data-act="stop-survey">停止</button>
      </div>
      ${progressHtml('sv-prog')}
    </div>
    <div class="card"><h3>草稿</h3><div id="sv-out"><div class="empty">输入主题后生成。</div></div>
      <div class="row" id="sv-actions" style="display:none;margin-top:10px">
        <button class="btn sm" data-act="copy-survey">复制全文</button>
      </div>
    </div>`
  );
}

async function doSurvey() {
  const topic = $('#sv-topic').value.trim();
  if (!topic) return toast('请输入主题');
  S.jobId = api.newId('job');
  $('#sv-out').innerHTML = '<div class="empty">检索证据并撰写中…（逐节生成，请稍候）</div>';
  $('#evidence').classList.remove('hidden');
  $('#ev-body').innerHTML = '<div class="hint">准备中…</div>';
  try {
    const d = await call('survey:generate', { topic, jobId: S.jobId });
    S.lastSurvey = d;
    $('#sv-out').innerHTML =
      d.sections.map((s) => `<h4 style="margin:14px 0 6px;font-size:15px">${esc(s.title)}</h4><div class="answer">${renderRich(s.content)}</div>`).join('') +
      `<div class="hint" style="margin-top:14px">共引用 ${d.evidence.length} 条证据，见右侧「证据与出处」。</div>`;
    $('#sv-actions').style.display = 'flex';
    renderEvidence(d.evidence);
    toast('生成完成，请逐条核对证据');
  } catch (e) {
    $('#sv-out').innerHTML = `<div class="empty" style="color:var(--red)">${esc(e.message)}</div>`;
  }
}

// ---- 写作辅助
function viewWrite() {
  return (
    head('写作辅助', '润色、摘要、Related Work、Methods、审稿回复 —— 不改变事实与数据，只改表达与结构。') +
    `<div class="card">
      <div class="row">
        <select id="w-mode" style="width:180px">
          <option value="polish">学术润色</option>
          <option value="abstract">生成结构化摘要</option>
          <option value="relatedwork">Related Work 改写</option>
          <option value="method">Methods 规范化</option>
          <option value="rebuttal">审稿意见回复</option>
        </select>
        <button class="btn primary" data-act="do-write">生成</button>
      </div>
      <textarea id="w-in" rows="8" style="margin-top:10px" placeholder="粘贴你的文字；若是审稿回复，把审稿意见也贴进来。"></textarea>
      <textarea id="w-ctx" rows="2" style="margin-top:8px" placeholder="补充上下文（可选）：论文主题、目标期刊、字数要求"></textarea>
    </div>
    <div class="card"><h3>输出</h3><div id="w-out" class="answer"><span class="hint">结果在这里流式输出。</span></div>
      <div class="row" style="margin-top:10px"><button class="btn sm" data-act="copy-write">复制</button></div>
    </div>`
  );
}

async function doWrite() {
  const text = $('#w-in').value.trim();
  if (!text) return toast('请输入内容');
  const out = $('#w-out');
  S.streamId = api.newId('s');
  S.streamBuf = '';
  out.className = 'answer streaming';
  out.innerHTML = '';
  try {
    await call('write:assist', { mode: $('#w-mode').value, text, context: $('#w-ctx').value.trim(), streamId: S.streamId });
    out.classList.remove('streaming');
  } catch (e) {
    out.classList.remove('streaming');
    out.innerHTML = `<span style="color:var(--red)">${esc(e.message)}</span>`;
  }
}

// ---- 设置
function viewSettings() {
  const p = S.presets || [];
  const cur = (S.config && S.config.provider) || '';
  const cfg = cur ? S.config.providers[cur] || {} : {};
  const preset = p.find((x) => x.id === cur);
  const f = S.config?.features || {};
  return (
    head('模型与设置', '算力由你自己接：换个 base_url 就换一家供应商，价格与用量全部可见。Key 只存在本机。') +
    `<div class="card">
      <h3>当前算力</h3>
      <div class="row">
        <select id="st-provider" style="max-width:280px">
          <option value="">选择供应商…</option>
          ${p.map((x) => `<option value="${x.id}" ${x.id === cur ? 'selected' : ''}>${esc(x.label)}</option>`).join('')}
        </select>
        <button class="btn" data-act="test-conn">测试连接</button>
        <button class="btn ghost" data-act="fetch-models">拉取模型列表</button>
      </div>
      <div class="row" style="margin-top:10px">
        <input type="text" id="st-base" class="grow" placeholder="API 地址，例如 https://api.deepseek.com/v1" value="${esc(cfg.baseUrl || preset?.baseUrl || '')}" />
        <input type="text" id="st-model" placeholder="模型名" list="model-list" style="max-width:240px" value="${esc(cfg.model || '')}" />
        <datalist id="model-list">${(preset?.models || []).map((m) => `<option value="${esc(m)}"></option>`).join('')}</datalist>
      </div>
      <div class="row" style="margin-top:10px">
        <input type="password" id="st-key" class="grow" placeholder="API Key（留空则沿用已保存的 Key）" />
        <input type="text" id="st-emb" placeholder="Embedding 模型（可选）" style="max-width:240px" value="${esc(cfg.embeddingModel || '')}" />
      </div>
      <div class="row" style="margin-top:10px">
        <input type="number" id="st-pin" placeholder="输入 元/百万" style="width:130px" value="${cfg.pricePerMTok?.in ?? preset?.price?.in ?? 0}" />
        <input type="number" id="st-pout" placeholder="输出 元/百万" style="width:130px" value="${cfg.pricePerMTok?.out ?? preset?.price?.out ?? 0}" />
        <span class="hint">价格仅用于本地成本估算，改不改不影响调用</span>
      </div>
      <div class="row" style="margin-top:10px"><button class="btn primary" data-act="save-provider">保存配置</button></div>
      <div id="st-msg" class="hint" style="margin-top:8px"></div>
    </div>

    <div class="card">
      <h3>检索与写作</h3>
      <div class="row">
        <label class="chk"><input type="checkbox" id="st-vec" ${f.useEmbeddingRerank ? 'checked' : ''} /> 启用向量语义重排（需供应商支持 /embeddings，检索更准但更费 token）</label>
      </div>
      <div class="row" style="margin-top:10px">
        <span style="width:150px" class="hint">翻译每批字符数</span>
        <input type="number" id="st-batch" style="width:120px" value="${f.translateBatchChars || 1600}" />
        <span style="width:150px" class="hint">检索返回片段数</span>
        <input type="number" id="st-topk" style="width:120px" value="${f.retrievalTopK || 12}" />
      </div>
      <div class="row" style="margin-top:10px">
        <span style="width:150px" class="hint">礼貌邮箱（OpenAlex/Crossref）</span>
        <input type="text" id="st-mail" style="max-width:260px" value="${esc(f.politeEmail || '')}" placeholder="you@university.edu" />
      </div>
      <div class="row" style="margin-top:10px"><button class="btn primary" data-act="save-features">保存</button></div>
    </div>

    <div class="card">
      <h3>用量与成本</h3>
      <div id="usage-box"><span class="hint">加载中…</span></div>
      <div class="row" style="margin-top:10px">
        <button class="btn sm" data-act="refresh-usage">刷新</button>
        <button class="btn sm ghost" data-act="clear-usage">清空记录</button>
      </div>
    </div>

    <div class="card">
      <h3>关于</h3>
      <div class="hint">
        ScholarDesk 是本地优先的科研助手：文献与译文都存在你自己的电脑里，模型调用直连你选择的供应商。
        AI 生成的综述、译文与结论只是初稿，学术输出请务必逐条回到原文核对。
      </div>
      <div class="row" style="margin-top:10px"><button class="btn sm" data-act="reveal-dir">打开数据目录</button></div>
    </div>`
  );
}

async function loadUsage() {
  const box = document.getElementById('usage-box');
  if (!box) return;
  try {
    const u = await call('usage:summary', { days: 30 });
    const rows = Object.entries(u.byFeature || {})
      .map(([k, v]) => `<tr><td>${esc(k)}</td><td>${v} 元</td></tr>`)
      .join('');
    const prov = Object.entries(u.byProvider || {})
      .map(([k, v]) => `<tr><td>${esc(k)}</td><td>${v} 元</td></tr>`)
      .join('');
    box.innerHTML = `<table class="kv">
      <tr><td>近 ${u.days} 天调用</td><td>${u.calls} 次 · ${(u.totalTokens / 1000).toFixed(1)}k tokens</td></tr>
      <tr><td>累计成本（估算）</td><td><strong>${u.totalCostYuan} 元</strong></td></tr>
    </table>
    ${prov ? `<div style="margin-top:10px"><div class="hint">按供应商</div><table class="kv">${prov}</table></div>` : ''}
    ${rows ? `<div style="margin-top:10px"><div class="hint">按功能</div><table class="kv">${rows}</table></div>` : ''}`;
  } catch (e) {
    box.innerHTML = `<span class="hint">${esc(e.message)}</span>`;
  }
}

// ------------------------------------------------------------------ 事件

async function importPdf() {
  try {
    const d = await call('library:importDialog');
    const ok = (d.imported || []).filter((x) => x.ok).length;
    const bad = (d.imported || []).filter((x) => !x.ok);
    await refreshLibrary();
    if (S.view === 'library') renderLibTable();
    if (S.view === 'translate' || S.view === 'qa') setView(S.view);
    if (ok) toast(`成功导入 ${ok} 篇`);
    if (bad.length) toast(`${bad.length} 篇失败：${bad[0].error}`, true);
  } catch (e) {
    toast(e.message, true);
  }
}

async function importText() {
  const title = prompt('文献标题（必填）');
  if (!title) return;
  const text = prompt('粘贴全文文本（支持从 PDF 阅读器复制、OCR 结果、LaTeX 全文）');
  if (!text) return;
  const authors = prompt('作者（可选）') || '';
  const year = Number(prompt('年份（可选）') || '') || null;
  await call('library:importText', { title, text, authors, year });
  await refreshLibrary();
  if (S.view === 'library') renderLibTable();
  toast('已导入');
}

async function saveProvider() {
  const id = $('#st-provider').value;
  if (!id) return toast('请先选择供应商', true);
  const patch = {
    baseUrl: $('#st-base').value.trim(),
    model: $('#st-model').value.trim(),
    embeddingModel: $('#st-emb').value.trim(),
    pricePerMTok: { in: Number($('#st-pin').value) || 0, out: Number($('#st-pout').value) || 0 },
  };
  const key = $('#st-key').value.trim();
  if (key) patch.apiKey = key;
  await call('config:setProvider', { id, patch });
  await call('config:selectProvider', { id });
  await loadConfig();
  toast('已保存');
}

async function testConn() {
  const id = $('#st-provider').value;
  if (!id) return toast('请先选择供应商', true);
  const msg = $('#st-msg');
  msg.textContent = '测试中…';
  try {
    const patch = {
      baseUrl: $('#st-base').value.trim(),
      model: $('#st-model').value.trim(),
    };
    const key = $('#st-key').value.trim();
    if (key) patch.apiKey = key;
    const r = await call('provider:test', { id, patch });
    msg.innerHTML = `<span style="color:var(--green)">连接成功：${esc(r.sample)}（${r.latencyMs}ms）</span>`;
    await loadConfig();
  } catch (e) {
    msg.innerHTML = `<span style="color:var(--red)">${esc(e.message)}</span>`;
  }
}

document.addEventListener('click', async (e) => {
  const nav = e.target.closest('.nav-item');
  if (nav) return setView(nav.dataset.view);

  const docItem = e.target.closest('.doc-item');
  if (docItem) {
    S.selectedDocId = docItem.dataset.doc;
    renderDocList();
    return;
  }

  const cite = e.target.closest('.cite');
  if (cite) {
    const n = Number(cite.dataset.n);
    $('#evidence').classList.remove('hidden');
    const el = document.querySelectorAll('.ev-item')[n - 1];
    if (el) {
      el.scrollIntoView({ block: 'center' });
      el.style.borderColor = 'var(--accent)';
      setTimeout(() => (el.style.borderColor = ''), 1600);
    }
    return;
  }

  const btn = e.target.closest('[data-act]');
  if (!btn) return;
  const act = btn.dataset.act;

  try {
    switch (act) {
      case 'import':
        return importPdf();
      case 'import-text':
        return importText();
      case 'reveal-dir':
        return void (await call('app:openDataDir'));
      case 'del': {
        if (!confirm('确定从知识库移除这篇文献？（不会删除磁盘上的原文件）')) return;
        await call('library:remove', { docId: btn.dataset.doc });
        await refreshLibrary();
        if (S.view === 'library') renderLibTable();
        return toast('已移除');
      }
      case 'reveal':
        return void (await call('library:reveal', { docId: btn.dataset.doc }));
      case 'peek': {
        const d = await call('library:getDoc', { docId: btn.dataset.doc });
        mainEl().innerHTML =
          head(esc(d.title), '按页码排布的原文片段') +
          `<div class="card">${d.chunks
            .slice(0, 40)
            .map(
              (c) => `<div class="result"><div class="ra">p.${c.page} · ${esc(c.section)}</div><div class="rabs">${esc(c.text.slice(0, 300))}…</div></div>`
            )
            .join('')}</div><div class="row"><button class="btn" data-act="back-library">返回列表</button></div>`;
        return;
      }
      case 'back-library':
        return setView('library');
      case 'to-translate':
        setView('translate');
        setTimeout(() => {
          const sel = document.getElementById('tr-doc');
          if (sel) sel.value = btn.dataset.doc;
        }, 30);
        return;
      case 'do-search':
        return doSearch();
      case 'open':
        e.preventDefault();
        return void (await call('search:openUrl', { url: btn.dataset.url }));
      case 'exp-bib':
        return void (await call('search:export', { items: S.searchResults, format: 'bibtex' }));
      case 'exp-gb':
        return void (await call('search:export', { items: S.searchResults, format: 'gb7714' }));
      case 'ask':
        return askQuestion();
      case 'stop-qa':
        S.streamId = null;
        $('#qa-out').classList.remove('streaming');
        return;
      case 'do-translate':
        return doTranslate();
      case 'stop-translate':
        return void (await call('survey:cancel', { jobId: S.jobId }));
      case 'exp-md':
        return void (await call('translate:export', { segments: S.lastTranslate.segments, meta: S.lastTranslate.meta, format: 'md' }));
      case 'exp-html':
        return void (await call('translate:export', { segments: S.lastTranslate.segments, meta: S.lastTranslate.meta, format: 'html' }));
      case 'do-survey':
        return doSurvey();
      case 'stop-survey':
        return void (await call('survey:cancel', { jobId: S.jobId }));
      case 'copy-survey':
        if (S.lastSurvey) navigator.clipboard.writeText(S.lastSurvey.markdown);
        return toast('已复制');
      case 'do-write':
        return doWrite();
      case 'copy-write':
        navigator.clipboard.writeText($('#w-out').innerText);
        return toast('已复制');
      case 'save-provider':
        return saveProvider();
      case 'test-conn':
        return testConn();
      case 'fetch-models': {
        const ms = await call('provider:models', { id: $('#st-provider').value });
        if (!ms.length) return toast('该端点未返回模型列表，请手动填写模型名', true);
        $('#model-list').innerHTML = ms.map((m) => `<option value="${esc(m)}"></option>`).join('');
        return toast(`获取到 ${ms.length} 个模型，可在模型名输入框下拉选择`);
      }
      case 'save-features': {
        await call('config:set', { path: 'features.useEmbeddingRerank', value: $('#st-vec').checked });
        await call('config:set', { path: 'features.translateBatchChars', value: Number($('#st-batch').value) || 1600 });
        await call('config:set', { path: 'features.retrievalTopK', value: Number($('#st-topk').value) || 12 });
        await call('config:set', { path: 'features.politeEmail', value: $('#st-mail').value.trim() });
        await loadConfig();
        return toast('已保存');
      }
      case 'refresh-usage':
        return loadUsage();
      case 'clear-usage':
        await call('usage:clear');
        return loadUsage();
      default:
    }
  } catch (err) {
    toast(err.message, true);
  }
});

$('#btn-import').addEventListener('click', importPdf);
$('#btn-quick-settings').addEventListener('click', () => setView('settings'));
$('#btn-close-ev').addEventListener('click', () => $('#evidence').classList.add('hidden'));

// 供应商切换时带出预设
document.addEventListener('change', (e) => {
  if (e.target.id === 'st-provider') {
    const id = e.target.value;
    const preset = (S.presets || []).find((x) => x.id === id);
    const cfg = (S.config?.providers || {})[id] || {};
    if (preset) {
      $('#st-base').value = cfg.baseUrl || preset.baseUrl || '';
      $('#st-model').value = cfg.model || preset.models[0] || '';
      $('#st-pin').value = cfg.pricePerMTok?.in ?? preset.price?.in ?? 0;
      $('#st-pout').value = cfg.pricePerMTok?.out ?? preset.price?.out ?? 0;
      $('#model-list').innerHTML = (preset.models || []).map((m) => `<option value="${esc(m)}"></option>`).join('');
    }
  }
});

// ------------------------------------------------------------------ 推送

api.on('stream:delta', ({ id, delta }) => {
  if (id !== S.streamId) return;
  S.streamBuf += delta;
  const box = $('#qa-out')?.classList.contains('streaming') ? $('#qa-out') : $('#w-out');
  if (box) box.innerHTML = renderRich(S.streamBuf);
});

api.on('job:progress', ({ id, phase, current, total }) => {
  if (id !== S.jobId) return;
  if (document.getElementById('sv-prog')) setProgress('sv-prog', current, total, phase);
  if (document.getElementById('tr-prog')) setProgress('tr-prog', current, total, phase);
});

api.on('library:progress', ({ file, phase }) => {
  const t = $('#toast');
  t.textContent = `${phase}：${file.split(/[\\/]/).pop()}`;
  t.className = 'toast';
});

api.on('menu:import', importPdf);

// ------------------------------------------------------------------ 启动

(async function init() {
  try {
    await loadConfig();
    await refreshLibrary();
    setView('library');
    if (!S.config.provider || !S.hasKey[S.config.provider]) {
      setTimeout(() => toast('还没配置模型，去「模型与设置」填入 API Key 即可使用', false), 800);
    }
  } catch (e) {
    mainEl().innerHTML = `<div class="empty">初始化失败：${esc(e.message)}</div>`;
  }
})();
