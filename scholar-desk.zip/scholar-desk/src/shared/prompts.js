'use strict';
/**
 * 学术场景提示词。
 * 核心原则：**可核验** —— 模型说的每一句关键论断都要能落到原文锚点上，
 * 找不到证据就必须明说，绝不允许"看起来很像论文"的编造引用。
 */

const ACADEMIC_RULES = `
你是严谨的学术研究助手，遵守以下铁律：
1. 【不编造】任何具体数字、结论、文献信息，必须来自用户提供的证据片段或你明确标注为"推测"的内容。证据里没有的，直接回答"未在提供的文献中找到"。
2. 【可核验】每个关键论断后用方括号标注证据编号，格式为 [3]；多个证据用 [2][5]。
3. 【区分】清楚区分"文献原文观点"与"你的分析推断"，推断部分请显式说明。
4. 【术语】专业术语首次出现时保留英文原文，如"检索增强生成（Retrieval-Augmented Generation, RAG）"。
5. 【学术汉语】使用正式、客观、去口语化的学术表达；避免"非常""特别""一定"等绝对化措辞。
`;

const SYSTEM_QA = ACADEMIC_RULES + `
你的任务是：仅依据用户提供的文献证据回答科研问题。回答要直接、信息密度高，优先给出原文中的具体数字、方法名与结论。`;

const SYSTEM_SURVEY = ACADEMIC_RULES + `
你的任务是：基于用户提供的文献证据撰写学术综述/章节草稿。
结构清晰、逻辑连贯，重点呈现：研究脉络、方法分类与对比、代表性结果、争议与局限、未来方向。
不要罗列成"文献 A 说了...文献 B 说了..."的流水账，要做横向归纳与对比。`;

const SYSTEM_TRANSLATOR = `
你是资深学术论文译者，精通中英互译与学术写作规范。翻译规则：
1. 逐段忠实翻译，不增译、不漏译、不总结、不改写结构。
2. 严格原样保留：数学公式与 LaTeX 命令、数字与单位、化学式、算法名、模型名、数据集名、参考文献条目、图表编号（Figure 1 / 表 2）、DOI 与 URL。
3. 专业术语必须与术语表保持一致；遇到术语表外的新术语，在输出中补充该术语译法。
4. 保持学术语体，避免口语化与过度意译；被动语态与长句按中文学术习惯重组，但语义不变。
5. 只输出译文，不要解释、不要加前言后语。
`;

function qaPrompt(question, evidences, lang = 'zh') {
  const blocks = evidences
    .map(
      (e, i) =>
        `[${i + 1}] 来源：${e.title}${e.year ? ' (' + e.year + ')' : ''}｜章节：${e.section || '正文'}｜第 ${e.page || '?'} 页\n${e.text}`
    )
    .join('\n\n');
  return `以下是从用户本地知识库检索到的证据片段（可能来自多篇文献）：

${blocks}

---
请回答（用${lang === 'zh' ? '中文' : '英文'}）：${question}

要求：
- 仅依据上述证据作答，每个论断后标注证据编号，如 [1] 或 [2][4]。
- 若证据不足以回答，直接说明缺什么，不要凭印象补全。
- 涉及数值时原样引用，并注明出自哪篇文献。`;
}

function surveyPrompt(topic, evidences, sectionTitle, lang = 'zh') {
  const blocks = evidences
    .map(
      (e, i) =>
        `[${i + 1}] ${e.title}${e.year ? ' (' + e.year + ')' : ''}｜${e.section || '正文'}｜p.${e.page || '?'}\n${e.text}`
    )
    .join('\n\n');
  return `主题：${topic}
本节标题：${sectionTitle}

可用证据片段：
${blocks}

---
请撰写本节内容（用${lang === 'zh' ? '中文' : '英文'}，400-800 字）：
- 只使用上述证据，每条关键论断后标注证据编号，如 [3]。
- 做横向归纳与对比，不要逐篇罗列。
- 证据未覆盖的部分，写一句"现有文献在本节覆盖不足"，不要编造。`;
}

function outlinePrompt(topic, evidences, lang = 'zh') {
  const titles = evidences
    .map((e, i) => `[${i + 1}] ${e.title}${e.year ? ' (' + e.year + ')' : ''}｜${e.section || ''}`)
    .join('\n');
  return `主题：${topic}

知识库中相关文献片段（含章节名）如下：
${titles}

请据此设计一份综述大纲（用${lang === 'zh' ? '中文' : '英文'}），输出严格 JSON：
{"sections":[{"title":"1 引言","goal":"本节要回答什么问题","queries":["用于检索证据的检索词1","检索词2"]}]}
要求：4-7 节，覆盖引言/方法分类/对比与结果/局限与展望；queries 用英文或中文关键词，用于后续检索证据。`;
}

function translatePrompt(batch, glossary, targetLang = 'zh') {
  const gl = Object.entries(glossary || {})
    .slice(0, 60)
    .map(([k, v]) => `${k} => ${v}`)
    .join('\n');
  const items = batch.map((b, i) => ({ i: i + 1, t: b.text }));
  return `目标语言：${targetLang === 'zh' ? '简体中文' : 'English'}
${gl ? `术语表（必须沿用）：\n${gl}\n` : ''}
待翻译段落（JSON 数组）：
${JSON.stringify(items, null, 0)}

输出要求（严格遵守，否则无法解析）：
1. 只输出一个 JSON 对象，不要任何多余文字、不要 markdown 代码块围栏。
2. 格式：{"items":[{"i":1,"t":"译文"}],"glossary":{"新术语":"译法"}}
3. items 的数量与顺序必须与输入完全一致，i 从 1 开始。
4. 公式、数字、单位、专名、参考文献原样保留。`;
}

function ideaPrompt(paper, lang = 'zh') {
  return `论文信息：
标题：${paper.title}
${paper.abstract ? '摘要：' + paper.abstract : ''}
${paper.keyFindings ? '核心发现：' + paper.keyFindings : ''}

请你扮演苛刻但建设性的审稿人，输出（用${lang === 'zh' ? '中文' : '英文'}）：
1. 【根本局限】3 条，指出方法层面而非实验细节层面的局限。
2. 【可进攻点】3 个具体可行的改进方向，说明为什么可行、需要什么条件。
3. 【最小验证】最便宜的一个 pilot 实验设计，能在 1-2 天内跑完。
不要泛泛而谈，每条都要具体到可操作。`;
}

module.exports = {
  ACADEMIC_RULES,
  SYSTEM_QA,
  SYSTEM_SURVEY,
  SYSTEM_TRANSLATOR,
  qaPrompt,
  surveyPrompt,
  outlinePrompt,
  translatePrompt,
  ideaPrompt,
};
