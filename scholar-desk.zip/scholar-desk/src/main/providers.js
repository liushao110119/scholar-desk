'use strict';
/**
 * 模型适配层 —— 这是整个软件"不被充值绑定"的关键。
 *
 * 设计原则：
 *  1. 统一走 OpenAI 兼容协议（/chat/completions、/embeddings）。
 *     目前 DeepSeek / 通义 / Kimi / 智谱 / 硅基流动 / Ollama / vLLM / LM Studio
 *     全都支持这套协议，换供应商 = 换一个 base_url + 模型名，代码零改动。
 *  2. Key 只存在本机，请求直连供应商，不经过任何中间服务器。
 *  3. 每次调用都回收 usage，按价格表折算成本，你自己看得见花了多少钱。
 *  4. 支持流式 SSE 输出。
 */

// ---------------------------------------------------------------- 预设供应商

const PRESETS = {
  deepseek: {
    label: 'DeepSeek',
    baseUrl: 'https://api.deepseek.com/v1',
    models: ['deepseek-chat', 'deepseek-reasoner'],
    embedding: false,
    price: { in: 2, out: 8 }, // 元 / 百万 token（缓存未命中），可在设置里覆盖
  },
  dashscope: {
    label: '通义千问（阿里云百炼）',
    baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
    models: ['qwen-plus', 'qwen-max', 'qwen-turbo'],
    embedding: true,
    price: { in: 0.8, out: 2 },
  },
  moonshot: {
    label: 'Kimi（Moonshot）',
    baseUrl: 'https://api.moonshot.cn/v1',
    models: ['moonshot-v1-32k', 'moonshot-v1-128k'],
    embedding: false,
    price: { in: 12, out: 12 },
  },
  zhipu: {
    label: '智谱 GLM',
    baseUrl: 'https://open.bigmodel.cn/api/paas/v4',
    models: ['glm-4-flash', 'glm-4-plus', 'glm-4.6'],
    embedding: true,
    price: { in: 1, out: 1 },
  },
  siliconflow: {
    label: '硅基流动 SiliconFlow',
    baseUrl: 'https://api.siliconflow.cn/v1',
    models: ['deepseek-ai/DeepSeek-V3', 'Qwen/Qwen2.5-72B-Instruct', 'THUDM/glm-4-9b-chat'],
    embedding: true, // BAAI/bge-m3
    price: { in: 2, out: 8 },
  },
  openai: {
    label: 'OpenAI',
    baseUrl: 'https://api.openai.com/v1',
    models: ['gpt-4o-mini', 'gpt-4o'],
    embedding: true,
    price: { in: 5, out: 40 },
  },
  ollama: {
    label: '本地 Ollama',
    baseUrl: 'http://localhost:11434/v1',
    models: ['qwen2.5:14b', 'llama3.1:8b', 'deepseek-r1:14b'],
    embedding: true, // nomic-embed-text / bge-m3
    price: { in: 0, out: 0 }, // 本地模型不花钱，只耗电
  },
  custom: {
    label: '自定义（OpenAI 兼容）',
    baseUrl: '',
    models: [],
    embedding: false,
    price: { in: 0, out: 0 },
  },
};

function listPresets() {
  return Object.entries(PRESETS).map(([id, p]) => ({
    id,
    label: p.label,
    baseUrl: p.baseUrl,
    models: p.models,
    embedding: p.embedding,
  }));
}

function normalizeBaseUrl(url) {
  if (!url) return '';
  let u = String(url).trim().replace(/\/+$/, '');
  // 用户可能填 https://api.deepseek.com 或 .../v1，统一成 .../v1
  if (!/\/v\d+$/.test(u)) u += '/v1';
  return u;
}

// ---------------------------------------------------------------- 客户端

class TimeoutError extends Error {
  constructor(ms) {
    super(`请求超时（${ms}ms）`);
    this.name = 'TimeoutError';
  }
}

async function withTimeout(promise, ms, signal) {
  let timer;
  const t = new Promise((_, rej) => {
    timer = setTimeout(() => rej(new TimeoutError(ms)), ms);
  });
  try {
    return await Promise.race([promise, t]);
  } finally {
    clearTimeout(timer);
    if (signal) signal.__timer = null;
  }
}

/**
 * 非流式对话。
 * @param {object} cfg {baseUrl, apiKey, model}
 * @param {Array<{role:string,content:string}>} messages
 * @param {object} opts {temperature, maxTokens, responseFormat, timeout}
 * @returns {Promise<{content:string, usage:object, raw:object}>}
 */
async function chat(cfg, messages, opts = {}) {
  const base = normalizeBaseUrl(cfg.baseUrl);
  if (!base) throw new Error('未配置 API 地址（baseUrl）');
  if (!cfg.model) throw new Error('未配置模型名');

  const body = {
    model: cfg.model,
    messages,
    temperature: opts.temperature ?? 0.3,
    stream: false,
  };
  if (opts.maxTokens) body.max_tokens = opts.maxTokens;
  if (opts.responseFormat) body.response_format = opts.responseFormat;
  if (opts.extra) Object.assign(body, opts.extra);

  const res = await _fetchJSON(`${base}/chat/completions`, body, cfg.apiKey, opts.timeout);
  const choice = res?.choices?.[0];
  const content = choice?.message?.content ?? '';
  return {
    content: typeof content === 'string' ? content : JSON.stringify(content),
    usage: res?.usage || { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 },
    raw: res,
  };
}

/**
 * 流式对话。onDelta(text) 逐段回调，最终 resolve 完整文本 + usage。
 * 注意：多数供应商在 stream 模式下不返回 usage，这里做 token 估算兜底。
 */
async function chatStream(cfg, messages, onDelta, opts = {}) {
  const base = normalizeBaseUrl(cfg.baseUrl);
  if (!base) throw new Error('未配置 API 地址（baseUrl）');
  if (!cfg.model) throw new Error('未配置模型名');

  const body = {
    model: cfg.model,
    messages,
    temperature: opts.temperature ?? 0.3,
    stream: true,
  };
  if (opts.maxTokens) body.max_tokens = opts.maxTokens;

  const headers = { 'Content-Type': 'application/json' };
  if (cfg.apiKey) headers.Authorization = `Bearer ${cfg.apiKey}`;

  const res = await fetch(`${base}/chat/completions`, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
  });
  if (!res.ok) await _throwHTTP(res);

  const reader = res.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';
  let full = '';
  let usage = null;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';
    for (const line of lines) {
      const t = line.trim();
      if (!t.startsWith('data:')) continue;
      const payload = t.slice(5).trim();
      if (payload === '[DONE]') continue;
      let json;
      try {
        json = JSON.parse(payload);
      } catch {
        continue;
      }
      if (json.usage) usage = json.usage;
      const delta = json?.choices?.[0]?.delta?.content;
      if (delta) {
        full += delta;
        onDelta?.(delta);
      }
    }
  }
  return {
    content: full,
    usage: usage || { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0, estimated: true },
  };
}

/**
 * 向量化（可选）。用于语义重排；不支持的供应商会自动回退到纯 BM25。
 */
async function embed(cfg, texts, opts = {}) {
  const base = normalizeBaseUrl(cfg.baseUrl);
  if (!base) throw new Error('未配置 API 地址（baseUrl）');
  const model = opts.model || cfg.embeddingModel;
  if (!model) throw new Error('未配置 embedding 模型名');

  const input = Array.isArray(texts) ? texts : [texts];
  const res = await _fetchJSON(`${base}/embeddings`, { model, input }, cfg.apiKey, opts.timeout);
  const data = res?.data || [];
  return data.sort((a, b) => a.index - b.index).map((d) => d.embedding);
}

// ---------------------------------------------------------------- 内部

async function _fetchJSON(url, body, apiKey, timeout = 120000) {
  const headers = { 'Content-Type': 'application/json' };
  if (apiKey) headers.Authorization = `Bearer ${apiKey}`;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout || 120000);
  let res;
  try {
    res = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(body),
      signal: controller.signal,
    });
  } catch (e) {
    clearTimeout(timer);
    if (e.name === 'AbortError') throw new TimeoutError(timeout || 120000);
    throw new Error(`网络请求失败：${e.message}（检查 baseUrl 是否可达、是否需要代理）`);
  }
  clearTimeout(timer);

  if (!res.ok) await _throwHTTP(res);
  const text = await res.text();
  try {
    return JSON.parse(text);
  } catch {
    throw new Error(`返回不是合法 JSON（前 200 字符）：${text.slice(0, 200)}`);
  }
}

async function _throwHTTP(res) {
  let detail = '';
  try {
    detail = (await res.text()).slice(0, 300);
  } catch { /* ignore */ }
  const hints = {
    401: 'API Key 无效或已过期',
    403: '无权限：该 Key 可能没有这个模型的额度',
    404: '地址或模型名不存在，检查 baseUrl 与 model',
    429: '触发限流或余额不足，稍后重试',
  };
  throw new Error(`HTTP ${res.status}${hints[res.status] ? ' — ' + hints[res.status] : ''} ${detail}`);
}

/** 连通性自检：用极小请求验证 baseUrl + key + model 三者是否匹配 */
async function testConnection(cfg) {
  const started = Date.now();
  const r = await chat(
    cfg,
    [{ role: 'user', content: '回复两个字：正常' }],
    { maxTokens: 16, timeout: 30000 }
  );
  return { ok: true, latencyMs: Date.now() - started, sample: r.content.slice(0, 50) };
}

/** 拉取供应商支持的模型列表（部分端点支持 /models） */
async function listModels(cfg) {
  const base = normalizeBaseUrl(cfg.baseUrl);
  if (!base) return [];
  const headers = {};
  if (cfg.apiKey) headers.Authorization = `Bearer ${cfg.apiKey}`;
  try {
    const res = await fetch(`${base}/models`, { headers });
    if (!res.ok) return [];
    const json = await res.json();
    return (json?.data || []).map((m) => m.id).sort();
  } catch {
    return [];
  }
}

module.exports = {
  PRESETS,
  listPresets,
  normalizeBaseUrl,
  chat,
  chatStream,
  embed,
  testConnection,
  listModels,
};
