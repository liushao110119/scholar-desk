'use strict';
/**
 * 学术文献检索：聚合多个**免费公开**数据源，不依赖任何付费库。
 *
 *  - arXiv        : 预印本，CS/物理/数学最全，无需 Key
 *  - OpenAlex     : 3 亿+ 元数据综合库，无需 Key（填邮箱进 polite pool 更稳）
 *  - Crossref     : DOI 权威登记，期刊论文最全，无需 Key
 *  - SemanticScholar : 摘要与引用网络好，无需 Key（有速率限制，可选填 Key）
 *
 * 统一成同一篇 Paper 结构，去重后排序，并支持导出 BibTeX / GB-T 7714。
 */

const UA = 'ScholarDesk/0.1 (local AI research assistant; mailto:you@example.com)';

// ---------------------------------------------------------------- 各数据源

async function searchArxiv(query, { limit = 20, timeout = 20000 } = {}) {
  const url =
    'http://export.arxiv.org/api/query?search_query=' +
    encodeURIComponent(`all:"${query}"`) +
    `&start=0&max_results=${Math.min(limit, 50)}&sortBy=relevance&sortOrder=descending`;
  const res = await _fetch(url, timeout);
  const xml = await res.text();
  const entries = xml.match(/<entry>[\s\S]*?<\/entry>/g) || [];
  return entries.map((e, idx) => {
    const id = (_tag(e, 'id') || '').trim();
    const pdf = (e.match(/<link[^>]*title="pdf"[^>]*href="([^"]+)"/) || [])[1] || '';
    const authors = [...e.matchAll(/<author>\s*<name>([\s\S]*?)<\/name>/g)].map((m) => m[1].trim());
    const published = (_tag(e, 'published') || '').slice(0, 4);
    return {
      id: id || `arxiv-${idx}`,
      title: (_tag(e, 'title') || '').replace(/\s+/g, ' ').trim(),
      authors,
      year: Number(published) || null,
      venue: 'arXiv preprint',
      abstract: (_tag(e, 'summary') || '').replace(/\s+/g, ' ').trim(),
      doi: (e.match(/<arxiv:doi[^>]*>([\s\S]*?)<\/arxiv:doi>/) || [])[1] || '',
      url: id,
      pdfUrl: pdf || (id ? id.replace('/abs/', '/pdf/') : ''),
      citationCount: null,
      source: 'arxiv',
    };
  });
}

async function searchOpenAlex(query, { limit = 20, timeout = 20000, email = '' } = {}) {
  const mail = email ? `&mailto=${encodeURIComponent(email)}` : '';
  const url =
    'https://api.openalex.org/works?search=' +
    encodeURIComponent(query) +
    `&per-page=${Math.min(limit, 50)}${mail}`;
  const res = await _fetch(url, timeout);
  const json = await res.json();
  const rows = json.results || json.data || [];
  return rows.map((w) => ({
    id: w.id || '',
    title: (w.title || w.display_name || '').replace(/\s+/g, ' ').trim(),
    authors: (w.authorships || []).map((a) => (a.author && a.author.display_name) || '').filter(Boolean),
    year: w.publication_year || null,
    venue: (w.primary_location && w.primary_location.source && w.primary_location.source.display_name) || '',
    abstract: _reconstructAbstract(w.abstract_inverted_index),
    doi: (w.doi || '').replace(/^https?:\/\/doi\.org\//, ''),
    url: w.doi || w.id || '',
    pdfUrl: (w.open_access && w.open_access.oa_url) || '',
    citationCount: w.cited_by_count ?? null,
    source: 'openalex',
  }));
}

async function searchCrossref(query, { limit = 20, timeout = 20000, email = '' } = {}) {
  const mail = email ? `&mailto=${encodeURIComponent(email)}` : '';
  const url =
    'https://api.crossref.org/works?query=' + encodeURIComponent(query) + `&rows=${Math.min(limit, 50)}${mail}`;
  const res = await _fetch(url, timeout);
  const json = await res.json();
  const rows = (json.message && json.message.items) || [];
  return rows.map((w) => ({
    id: w.DOI || '',
    title: ((w.title || [])[0] || '').replace(/\s+/g, ' ').trim(),
    authors: (w.author || []).map((a) => [a.given, a.family].filter(Boolean).join(' ')).filter(Boolean),
    year: (w.issued && w.issued['date-parts'] && w.issued['date-parts'][0] && w.issued['date-parts'][0][0]) || null,
    venue: ((w['container-title'] || [])[0] || '') || (w.publisher || ''),
    abstract: _stripXml(w.abstract || ''),
    doi: w.DOI || '',
    url: w.URL || (w.DOI ? `https://doi.org/${w.DOI}` : ''),
    pdfUrl: (w.link || []).map((l) => l.URL).find((u) => u && /pdf/i.test(u)) || '',
    citationCount: w['is-referenced-by-count'] ?? null,
    source: 'crossref',
  }));
}

async function searchSemanticScholar(query, { limit = 20, timeout = 20000, apiKey = '' } = {}) {
  const url =
    'https://api.semanticscholar.org/graph/v1/paper/search?query=' +
    encodeURIComponent(query) +
    `&limit=${Math.min(limit, 50)}&fields=title,abstract,year,venue,authors,citationCount,externalIds,url,openAccessPdf`;
  const headers = { 'User-Agent': UA };
  if (apiKey) headers['x-api-key'] = apiKey;
  const res = await _fetch(url, timeout, headers);
  const json = await res.json();
  const rows = json.data || [];
  return rows.map((w) => ({
    id: w.paperId || '',
    title: (w.title || '').trim(),
    authors: (w.authors || []).map((a) => a.name).filter(Boolean),
    year: w.year || null,
    venue: w.venue || '',
    abstract: w.abstract || '',
    doi: (w.externalIds && w.externalIds.DOI) || '',
    url: w.url || '',
    pdfUrl: (w.openAccessPdf && w.openAccessPdf.url) || '',
    citationCount: w.citationCount ?? null,
    source: 'semanticscholar',
  }));
}

// ---------------------------------------------------------------- 聚合

const SOURCES = {
  arxiv: { label: 'arXiv', fn: searchArxiv },
  openalex: { label: 'OpenAlex', fn: searchOpenAlex },
  crossref: { label: 'Crossref', fn: searchCrossref },
  semanticscholar: { label: 'Semantic Scholar', fn: searchSemanticScholar },
};

function listSources() {
  return Object.entries(SOURCES).map(([id, s]) => ({ id, label: s.label }));
}

/** 标题归一化，用于跨源去重（去标点、小写、去空格） */
function normTitle(t) {
  return String(t || '').toLowerCase().replace(/[^a-z0-9\u4e00-\u9fff]+/g, '');
}

function mergePapers(groups) {
  /** @type {Map<string, any>} */
  const byKey = new Map();
  for (const p of groups) {
    if (!p.title) continue;
    const key = (p.doi && p.doi.toLowerCase()) || normTitle(p.title);
    if (!key) continue;
    const exist = byKey.get(key);
    if (!exist) {
      byKey.set(key, { ...p, sources: [p.source] });
    } else {
      // 合并：补全缺失字段
      for (const f of ['abstract', 'doi', 'pdfUrl', 'venue', 'year', 'citationCount']) {
        if (!exist[f] && p[f]) exist[f] = p[f];
      }
      if (!exist.authors.length && p.authors.length) exist.authors = p.authors;
      if (!exist.sources.includes(p.source)) exist.sources.push(p.source);
    }
  }
  return [...byKey.values()];
}

/** 综合排序：相关性基础分 + 引用影响（对数）+ 年份新鲜度 */
function rankPapers(items, { yearFrom = 0, yearTo = 0 } = {}) {
  const nowYear = new Date().getFullYear();
  return items
    .filter((p) => (yearFrom ? (p.year || 0) >= yearFrom : true))
    .filter((p) => (yearTo ? (p.year || 9999) <= yearTo : true))
    .map((p) => {
      let score = 1;
      if (p.citationCount) score += Math.log10(p.citationCount + 1) * 0.6;
      if (p.year) {
        const age = Math.max(0, nowYear - p.year);
        score += Math.max(0, 1.2 - age * 0.06); // 近 20 年内递减
      }
      if (p.abstract) score += 0.3;
      if (p.pdfUrl) score += 0.2;
      return { ...p, score: Number(score.toFixed(3)) };
    })
    .sort((a, b) => b.score - a.score);
}

/**
 * 并行检索多个源，单个源失败不影响其他源。
 * @returns {Promise<{items:Array, errors:Array<{source:string,message:string}>}>}
 */
async function searchAll(query, opts = {}) {
  const wanted = opts.sources && opts.sources.length ? opts.sources : ['arxiv', 'openalex', 'crossref'];
  const limit = opts.limit || 20;
  const errors = [];
  const settled = await Promise.all(
    wanted.map(async (id) => {
      const s = SOURCES[id];
      if (!s) return [];
      try {
        return await s.fn(query, { ...opts, limit });
      } catch (e) {
        errors.push({ source: id, message: String(e.message || e) });
        return [];
      }
    })
  );
  const merged = mergePapers(settled.flat());
  return { items: rankPapers(merged, opts).slice(0, limit), errors };
}

// ---------------------------------------------------------------- 导出

function toBibTeX(items) {
  return items
    .map((p, i) => {
      const key = `${(p.authors[0] || 'anon').split(/\s+/).pop() || 'anon'}${p.year || ''}${String.fromCharCode(97 + (i % 26))}`;
      const type = /arxiv|preprint/i.test(p.venue || '') ? 'misc' : 'article';
      const fields = [
        ['title', p.title],
        ['author', p.authors.join(' and ')],
        ['year', p.year],
        p.venue ? [type === 'misc' ? 'howpublished' : 'journal', p.venue] : null,
        p.doi ? ['doi', p.doi] : null,
        p.url ? ['url', p.url] : null,
      ].filter(Boolean);
      return `@${type}{${key.replace(/[^A-Za-z0-9]/g, '')},\n${fields
        .map(([k, v]) => `  ${k} = {${v}}`)
        .join(',\n')}\n}`;
    })
    .join('\n\n');
}

/** GB/T 7714-2015（简化版，覆盖期刊/会议/预印本三种常见形态） */
function toGB7714(items) {
  return items
    .map((p, i) => {
      const isCN = /[\u4e00-\u9fff]/.test(p.title || '');
      let authors = p.authors || [];
      const more = isCN ? '等' : 'et al.';
      const authorStr = authors.length > 3 ? `${authors.slice(0, 3).join(', ')} ${more}` : authors.join(', ');
      let type = p.venue && /arxiv|preprint/i.test(p.venue) ? '[EB/OL]' : /proceedings|conf|workshop|neurips|icml|iclr|acl|cvpr|miccai/i.test(p.venue || '') ? '[C]' : '[J]';
      let line = `[${i + 1}] ${authorStr}. ${p.title}${type}. ${p.venue || ''}`;
      if (p.year) line += `, ${p.year}`;
      if (p.doi) line += `. DOI:${p.doi}`;
      else if (p.url) line += `. ${p.url}`;
      return line;
    })
    .join('\n');
}

// ---------------------------------------------------------------- 内部

async function _fetch(url, timeout = 20000, headers = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const res = await fetch(url, { headers: { 'User-Agent': UA, ...headers }, signal: controller.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res;
  } catch (e) {
    if (e.name === 'AbortError') throw new Error('检索超时');
    throw new Error(`检索失败：${e.message}（可能需要代理，或该数据源暂时不可用）`);
  } finally {
    clearTimeout(timer);
  }
}

function _tag(xml, name) {
  const m = xml.match(new RegExp(`<${name}[^>]*>([\\s\\S]*?)</${name}>`));
  return m ? m[1] : '';
}

function _stripXml(s) {
  return String(s || '').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
}

/** OpenAlex 的摘要是倒排索引，需要还原成文本 */
function _reconstructAbstract(inv) {
  if (!inv) return '';
  const slots = [];
  for (const [word, positions] of Object.entries(inv)) {
    for (const p of positions) slots[p] = word;
  }
  return slots.filter(Boolean).join(' ');
}

module.exports = {
  searchAll,
  searchArxiv,
  searchOpenAlex,
  searchCrossref,
  searchSemanticScholar,
  listSources,
  toBibTeX,
  toGB7714,
  normTitle,
  mergePapers,
  rankPapers,
  _reconstructAbstract,
};
