'use strict';
/**
 * 本地知识库：PDF/文本 -> 结构化 chunk -> BM25 索引 -> 带出处的检索。
 *
 * 全部落盘在本机数据目录，不上传任何服务器。
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { BM25Index } = require('./bm25');
const { parsePdfFile, buildChunks, segmentPages } = require('./pdf');

class Library {
  constructor(dataDir) {
    this.dir = path.join(dataDir, 'library');
    fs.mkdirSync(this.dir, { recursive: true });
    this.docsFile = path.join(this.dir, 'docs.json');
    this.indexFile = path.join(this.dir, 'index.json');
    /** @type {Map<string, any>} */
    this.docs = new Map();
    /** @type {Map<string, any>} id -> {docId, section, page, text} */
    this.chunks = new Map();
    this.index = BM25Index.load(this.indexFile);
    this._load();
  }

  // ------------------------------------------------------------- 持久化

  _load() {
    try {
      const raw = JSON.parse(fs.readFileSync(this.docsFile, 'utf8'));
      for (const d of raw.docs || []) this.docs.set(d.id, d);
      for (const c of raw.chunks || []) this.chunks.set(c.id, c);
    } catch { /* 首次运行 */ }
    // 索引缺失但数据还在 -> 重建
    if (this.chunks.size && !this.index.size) this.rebuildIndex();
  }

  _save() {
    fs.writeFileSync(
      this.docsFile,
      JSON.stringify({ version: 1, docs: [...this.docs.values()], chunks: [...this.chunks.values()] }, null, 2),
      'utf8'
    );
    this.index.save(this.indexFile);
  }

  rebuildIndex() {
    this.index.clear();
    for (const c of this.chunks.values()) {
      if (c.kind !== 'formula') this.index.add(c.id, `${c.section}\n${c.text}`);
    }
    this.index.save(this.indexFile);
  }

  // ------------------------------------------------------------- 入库

  /**
   * 导入 PDF。
   * @param {string} filePath
   * @param {(p:{phase:string, current:number, total:number})=>void} [onProgress]
   */
  async addPdf(filePath, onProgress) {
    onProgress?.({ phase: '解析 PDF', current: 0, total: 3 });
    const parsed = await parsePdfFile(filePath);
    onProgress?.({ phase: '切分与索引', current: 1, total: 3 });
    const docId = 'doc-' + crypto.createHash('md5').update(filePath + parsed.sizeBytes).digest('hex').slice(0, 12);
    const doc = {
      id: docId,
      title: parsed.title,
      authors: parsed.authors,
      year: parsed.year,
      file: filePath,
      fileName: parsed.fileName,
      numpages: parsed.numpages,
      source: 'pdf',
      addedAt: Date.now(),
      chunkCount: parsed.chunks.length,
      segmentCount: parsed.segments.length,
    };
    this.docs.set(docId, doc);
    for (const c of parsed.chunks) {
      const chunk = { id: c.id, docId, section: c.section, page: c.page, text: c.text };
      this.chunks.set(chunk.id, chunk);
      this.index.add(chunk.id, `${c.section}\n${c.text}`);
    }
    // 段落原文落盘：翻译时直接用，不必重复解析 PDF
    this._saveSegments(docId, parsed.segments);
    onProgress?.({ phase: '写入索引', current: 2, total: 3 });
    this._save();
    onProgress?.({ phase: '完成', current: 3, total: 3 });
    return doc;
  }

  /**
   * 导入纯文本（扫描件 OCR 结果、网页复制、LaTeX 全文均可）。
   * @param {{title:string, authors?:string, year?:number, text:string, source?:string}} input
   */
  addText(input) {
    const docId = 'doc-' + crypto.createHash('md5').update(input.title + Date.now()).digest('hex').slice(0, 12);
    const lines = String(input.text || '').split(/\r?\n/);
    const pages = lines.map((t) => ({ text: t, paraBreak: true }));
    const { segments } = segmentPages([pages]);
    const chunks = buildChunks(segments);
    const doc = {
      id: docId,
      title: input.title || '未命名文本',
      authors: input.authors || '',
      year: input.year || null,
      file: '',
      fileName: '',
      numpages: 1,
      source: input.source || 'text',
      addedAt: Date.now(),
      chunkCount: chunks.length,
      segmentCount: segments.length,
    };
    this.docs.set(docId, doc);
    for (const c of chunks) {
      const chunk = { id: c.id, docId, section: c.section, page: c.page, text: c.text };
      this.chunks.set(chunk.id, chunk);
      this.index.add(chunk.id, `${c.section}\n${c.text}`);
    }
    this._saveSegments(docId, segments);
    this._save();
    return doc;
  }

  _saveSegments(docId, segments) {
    try {
      const dir = path.join(this.dir, 'segments');
      fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(path.join(dir, docId + '.json'), JSON.stringify({ segments }), 'utf8');
    } catch { /* 落盘失败不影响主流程 */ }
  }

  remove(docId) {
    for (const [id, c] of [...this.chunks]) {
      if (c.docId === docId) {
        this.chunks.delete(id);
        this.index.remove(id);
      }
    }
    this.docs.delete(docId);
    this._save();
  }

  list() {
    return [...this.docs.values()].sort((a, b) => b.addedAt - a.addedAt);
  }

  getDoc(docId) {
    const doc = this.docs.get(docId);
    if (!doc) return null;
    return {
      ...doc,
      chunks: [...this.chunks.values()].filter((c) => c.docId === docId).sort((a, b) => a.page - b.page),
    };
  }

  // ------------------------------------------------------------- 检索

  /**
   * @param {string} query
   * @param {{topK?:number, docIds?:string[], rerank?:boolean, embedFn?:Function}} opts
   * @returns {Promise<Array>} 带文献出处的结果
   */
  async search(query, opts = {}) {
    const topK = opts.topK || 12;
    const filter = opts.docIds && opts.docIds.length ? new Set(this._chunkIdsOfDocs(opts.docIds)) : null;
    const recall = Math.min(Math.max(topK * 4, 40), 200);
    let hits = this.index.search(query, recall, filter);

    // 可选：向量语义重排（需要供应商支持 /embeddings）
    if (opts.rerank && typeof opts.embedFn === 'function' && hits.length > topK) {
      try {
        const texts = hits.map((h) => this.chunks.get(h.id)?.text || '');
        const [qv, ...dv] = await opts.embedFn([query, ...texts]);
        if (qv && dv.length === texts.length) {
          const scored = hits.map((h, i) => ({
            ...h,
            vec: _cosine(qv, dv[i]),
            bm25: h.score,
          }));
          const maxB = Math.max(...scored.map((s) => s.bm25)) || 1;
          scored.forEach((s) => {
            s.score = 0.45 * (s.bm25 / maxB) + 0.55 * s.vec;
          });
          hits = scored.sort((a, b) => b.score - a.score);
        }
      } catch { /* 重排失败就用 BM25 结果 */ }
    }

    return hits.slice(0, topK).map((h) => {
      const c = this.chunks.get(h.id);
      const d = this.docs.get(c.docId);
      return {
        chunkId: c.id,
        docId: c.docId,
        title: d?.title || '(已删除)',
        authors: d?.authors || '',
        year: d?.year || null,
        section: c.section,
        page: c.page,
        text: c.text,
        score: Number(h.score.toFixed(4)),
      };
    });
  }

  _chunkIdsOfDocs(docIds) {
    const set = new Set(docIds);
    const out = new Set();
    for (const c of this.chunks.values()) if (set.has(c.docId)) out.add(c.id);
    return [...out];
  }

  stats() {
    let chars = 0;
    for (const c of this.chunks.values()) chars += c.text.length;
    return { docs: this.docs.size, chunks: this.chunks.size, chars };
  }
}

function _cosine(a, b) {
  if (!a || !b || a.length !== b.length) return 0;
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  return na && nb ? dot / (Math.sqrt(na) * Math.sqrt(nb)) : 0;
}

module.exports = { Library };
