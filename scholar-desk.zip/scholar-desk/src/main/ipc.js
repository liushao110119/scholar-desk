'use strict';
/**
 * IPC 层：把主进程能力以"频道"形式暴露给界面。
 * 界面只调 api.invoke(channel, payload)，不直接碰 Node，安全边界清晰。
 */

const fs = require('fs');
const path = require('path');
const { dialog, shell, app } = require('electron');

const { PRESETS, listPresets, chat, chatStream, testConnection, listModels, embed } = require('./providers');
const { answerQuestion, generateSurvey, writeAssist, discoverIdeas } = require('./survey');
const { translateDocument, toBilingualMarkdown, toBilingualHTML } = require('./translate');
const { Library } = require('./library');
const { Usage } = require('./usage');
const search = require('./search');

// 正在跑的长任务，支持取消
const running = new Map();

function registerIpc({ store, dataDir }) {
  const library = new Library(dataDir);
  const usage = new Usage(dataDir);

  const currentProvider = () => store.get('provider');
  const cfgOf = (id) => store.getProviderConfig(id || currentProvider());
  const hookOf = (id) => {
    const pid = id || currentProvider();
    const cfg = cfgOf(pid);
    return (p) => usage.record({ provider: pid, model: cfg.model, feature: p.feature, usage: p.usage, pricePerMTok: cfg.pricePerMTok });
  };
  const embedFnOf = async (texts) => {
    const cfg = cfgOf();
    return embed(cfg, texts, { model: cfg.embeddingModel });
  };

  const handle = (ch, fn) => require('electron').ipcMain.handle(ch, async (_e, payload) => {
    try {
      return { ok: true, data: await fn(payload || {}) };
    } catch (e) {
      return { ok: false, error: String((e && e.message) || e) };
    }
  });

  // ------------------------------------------------------------ 配置

  handle('config:get', () => ({
    config: store.config,
    presets: listPresets(),
    hasKey: Object.fromEntries(
      Object.keys(PRESETS).map((id) => [id, !!store.getApiKey(id)])
    ),
  }));

  handle('config:set', ({ path: p, value }) => store.set(p, value));

  handle('config:setProvider', ({ id, patch }) => ({
    providers: store.setProviderOptions(id, patch || {}),
  }));

  handle('config:selectProvider', ({ id }) => store.set('provider', id));

  handle('provider:test', async ({ id, patch }) => {
    if (patch) store.setProviderOptions(id, patch);
    const cfg = cfgOf(id);
    const r = await testConnection(cfg);
    return { ...r, baseUrl: cfg.baseUrl, model: cfg.model };
  });

  handle('provider:models', async ({ id }) => listModels(cfgOf(id)));

  // ------------------------------------------------------------ 知识库

  handle('library:list', () => ({ docs: library.list(), stats: library.stats() }));

  handle('library:importDialog', async () => {
    const res = await dialog.showOpenDialog({
      title: '选择 PDF 文献',
      properties: ['openFile', 'multiSelections'],
      filters: [{ name: 'PDF 文档', extensions: ['pdf'] }],
    });
    if (res.canceled || !res.filePaths.length) return { imported: [] };
    const imported = [];
    for (const f of res.filePaths) {
      try {
        const doc = await library.addPdf(f, (p) => _push('library:progress', { file: f, ...p }));
        imported.push({ ok: true, doc });
      } catch (e) {
        imported.push({ ok: false, file: f, error: String(e.message || e) });
      }
    }
    return { imported, stats: library.stats() };
  });

  handle('library:importText', ({ title, authors, year, text }) => ({
    doc: library.addText({ title, authors, year, text, source: 'manual' }),
    stats: library.stats(),
  }));

  handle('library:remove', ({ docId }) => {
    library.remove(docId);
    return { stats: library.stats() };
  });

  handle('library:getDoc', ({ docId }) => library.getDoc(docId));

  handle('library:search', async ({ query, topK, docIds }) => {
    const cfg = cfgOf();
    const useVec = store.get('features.useEmbeddingRerank') && cfg.embeddingModel;
    return {
      hits: await library.search(query, {
        topK: topK || store.get('features.retrievalTopK') || 12,
        docIds,
        rerank: useVec,
        embedFn: useVec ? embedFnOf : undefined,
      }),
    };
  });

  handle('library:reveal', ({ docId }) => {
    const d = library.docs.get(docId);
    if (d && d.file) shell.showItemInFolder(d.file);
    return { ok: true };
  });

  // ------------------------------------------------------------ 问答 / 写作

  handle('qa:ask', async ({ question, docIds, topK, streamId }) => {
    const cfg = cfgOf();
    const useVec = store.get('features.useEmbeddingRerank') && cfg.embeddingModel;
    const onDelta = streamId
      ? (delta) => _push('stream:delta', { id: streamId, delta })
      : undefined;
    const r = await answerQuestion({
      library,
      cfg,
      question,
      docIds,
      topK,
      rerank: useVec,
      embedFn: useVec ? embedFnOf : undefined,
      usageHook: hookOf(),
      onDelta,
    });
    return r;
  });

  handle('survey:generate', async ({ topic, docIds, topK, jobId }) => {
    const cfg = cfgOf();
    const useVec = store.get('features.useEmbeddingRerank') && cfg.embeddingModel;
    running.set(jobId, false);
    const r = await generateSurvey({
      library,
      cfg,
      topic,
      docIds,
      topK,
      rerank: useVec,
      embedFn: useVec ? embedFnOf : undefined,
      usageHook: hookOf(),
      shouldStop: () => running.get(jobId) === true,
      onProgress: (p) => _push('job:progress', { id: jobId, ...p }),
    });
    running.delete(jobId);
    return r;
  });

  handle('survey:cancel', ({ jobId }) => {
    running.set(jobId, true);
    return { ok: true };
  });

  handle('write:assist', async ({ mode, text, context, streamId }) => {
    const r = await writeAssist({
      cfg: cfgOf(),
      mode,
      text,
      context,
      usageHook: hookOf(),
      onDelta: streamId ? (d) => _push('stream:delta', { id: streamId, delta: d }) : undefined,
    });
    return { text: r };
  });

  handle('idea:discover', async ({ paper, streamId }) => {
    const r = await discoverIdeas({
      cfg: cfgOf(),
      paper,
      usageHook: hookOf(),
      onDelta: streamId ? (d) => _push('stream:delta', { id: streamId, delta: d }) : undefined,
    });
    return { text: r };
  });

  // ------------------------------------------------------------ 翻译

  handle('translate:run', async ({ docId, targetLang, jobId }) => {
    const doc = library.getDoc(docId);
    if (!doc) throw new Error('文献不存在');
    const { segments } = await _loadSegments(doc, dataDir);
    running.set(jobId, false);
    const r = await translateDocument({
      segments,
      cfg: cfgOf(),
      docId,
      cacheDir: path.join(dataDir, 'cache'),
      targetLang: targetLang || 'zh',
      batchChars: store.get('features.translateBatchChars') || 1600,
      usageHook: hookOf(),
      shouldStop: () => running.get(jobId) === true,
      onProgress: (p) => _push('job:progress', { id: jobId, ...p }),
    });
    running.delete(jobId);
    _push('job:progress', { id: jobId, phase: '完成', current: 100, total: 100 });
    return {
      segments: r.segments,
      glossary: r.glossary,
      errors: r.errors,
      meta: { title: doc.title, authors: doc.authors, year: doc.year },
    };
  });

  handle('translate:export', async ({ docId, segments, meta, format }) => {
    const md = toBilingualMarkdown(segments, meta, format === 'table' ? 'table' : 'paragraph');
    const html = toBilingualHTML(segments, meta);
    const res = await dialog.showSaveDialog({
      title: '导出译文',
      defaultPath: `${(meta.title || 'translation').replace(/[\\/:*?"<>|]/g, '_')}.${format === 'html' ? 'html' : 'md'}`,
      filters: format === 'html'
        ? [{ name: '网页', extensions: ['html'] }]
        : [{ name: 'Markdown', extensions: ['md'] }],
    });
    if (res.canceled || !res.filePath) return { canceled: true };
    fs.writeFileSync(res.filePath, format === 'html' ? html : md, 'utf8');
    shell.showItemInFolder(res.filePath);
    return { file: res.filePath };
  });

  // ------------------------------------------------------------ 文献检索

  handle('search:literature', async ({ query, sources, limit, yearFrom, yearTo }) => ({
    ...(await search.searchAll(query, {
      sources,
      limit: limit || 20,
      yearFrom,
      yearTo,
      email: store.get('features.politeEmail') || '',
    })),
  }));

  handle('search:export', async ({ items, format }) => {
    const text = format === 'bibtex' ? search.toBibTeX(items) : search.toGB7714(items);
    const res = await dialog.showSaveDialog({
      title: '导出题录',
      defaultPath: `references.${format === 'bibtex' ? 'bib' : 'txt'}`,
      filters: [{ name: format === 'bibtex' ? 'BibTeX' : 'GB/T 7714', extensions: [format === 'bibtex' ? 'bib' : 'txt'] }],
    });
    if (res.canceled || !res.filePath) return { canceled: true };
    fs.writeFileSync(res.filePath, text, 'utf8');
    shell.showItemInFolder(res.filePath);
    return { file: res.filePath };
  });

  handle('search:openUrl', ({ url }) => {
    if (url) shell.openExternal(url);
    return { ok: true };
  });

  // ------------------------------------------------------------ 用量

  handle('usage:summary', ({ days }) => usage.summary({ days: days || 30 }));
  handle('usage:clear', () => {
    usage.clear();
    return { ok: true };
  });

  handle('app:paths', () => ({
    userData: app.getPath('userData'),
    dataDir,
  }));

  handle('app:openDataDir', () => {
    shell.openPath(dataDir);
    return { ok: true };
  });

  return { library, usage };
}

/** 从缓存/原文件重建 segments（翻译需要段落级原文） */
async function _loadSegments(doc, dataDir) {
  const cacheFile = path.join(dataDir, 'library', 'segments', `${doc.id}.json`);
  if (fs.existsSync(cacheFile)) {
    try {
      return JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
    } catch { /* 重建 */ }
  }
  const { parsePdfFile } = require('./pdf');
  let parsed;
  if (doc.file && fs.existsSync(doc.file)) {
    parsed = await parsePdfFile(doc.file);
  } else {
    throw new Error('原文文件已不存在，无法重新提取段落（该文献可能是手动导入的文本）');
  }
  fs.mkdirSync(path.dirname(cacheFile), { recursive: true });
  fs.writeFileSync(cacheFile, JSON.stringify({ segments: parsed.segments }), 'utf8');
  return { segments: parsed.segments };
}

function _push(channel, payload) {
  const { BrowserWindow } = require('electron');
  for (const w of BrowserWindow.getAllWindows()) w.webContents.send(channel, payload);
}

module.exports = { registerIpc };
