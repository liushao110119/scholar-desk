'use strict';
/**
 * PDF 解析 + 学术结构化切分。
 *
 * 目的不只是"把字抠出来"，而是保留科研最需要的东西：
 *  - 页码（引用要能定位到原文第几页）
 *  - 行与段落边界（PDF 里往往整页是一坨没有换行的字符串，
 *    必须靠文字坐标重建，否则切出来的 chunk 毫无结构）
 *  - 章节归属（综述写作时知道这段话出自方法还是结论）
 *  - 公式行（翻译时不该动它们）
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ---------------------------------------------------------------- 文本提取

/**
 * pdf.js 给的是一串带坐标的碎片（item），没有换行。
 * 这里按 y 坐标聚成行、按 x 排序拼接，再按行间距推断段落边界。
 */
function buildLinesFromItems(items) {
  const rows = [];
  for (const it of items || []) {
    const str = (it && it.str) || '';
    if (!str.trim()) continue;
    const tr = it.transform || [1, 0, 0, 1, 0, 0];
    const y = Math.round(tr[5] * 10) / 10;
    const x = tr[4] || 0;
    let row = null;
    for (const r of rows) {
      if (Math.abs(r.y - y) <= 2.5) {
        row = r;
        break;
      }
    }
    if (!row) {
      row = { y, parts: [] };
      rows.push(row);
    }
    row.parts.push({ x, str });
  }
  rows.sort((a, b) => b.y - a.y);

  const lines = rows.map((r) => {
    r.parts.sort((a, b) => a.x - b.x);
    let s = '';
    for (const p of r.parts) {
      if (!s) {
        s = p.str;
      } else if (/\s$/.test(s) || /^\s/.test(p.str)) {
        s += p.str;
      } else if (/[\u4e00-\u9fff]$/.test(s) || /^[\u4e00-\u9fff]/.test(p.str)) {
        s += p.str; // 中文之间不加空格
      } else {
        s += ' ' + p.str;
      }
    }
    return { text: s.replace(/[ \t]+/g, ' ').trim(), y: r.y };
  });

  // 行间距中位数 -> 判断"空行=新段落"
  const gaps = [];
  for (let i = 0; i < lines.length - 1; i++) {
    const g = lines[i].y - lines[i + 1].y;
    if (g > 0.5) gaps.push(g);
  }
  gaps.sort((a, b) => a - b);
  const median = gaps.length ? gaps[Math.floor(gaps.length / 2)] : 12;
  const threshold = Math.max(median * 1.6, median + 3);

  return lines.map((l, i) => ({
    text: l.text,
    paraBreak: i === 0 ? true : lines[i - 1].y - l.y > threshold,
  }));
}

async function _pdfjsEngine(buf) {
  let pdfjs;
  try {
    pdfjs = await import('pdfjs-dist/legacy/build/pdf.mjs');
  } catch {
    return null;
  }
  const opts = {
    data: new Uint8Array(buf),
    useSystemFonts: true,
    verbosity: 0,
    isEvalSupported: false,
  };
  // 未嵌入的中日韩 CID 字体需要标准 CMap
  try {
    const base = require.resolve('pdfjs-dist/package.json').replace(/package\.json$/, '');
    opts.cMapUrl = 'file://' + base + 'cmaps/';
    opts.cMapPacked = true;
    opts.standardFontDataUrl = 'file://' + base + 'standard_fonts/';
  } catch { /* 拿不到就按默认 */ }

  const doc = await pdfjs.getDocument(opts).promise;
  const pages = [];
  for (let i = 1; i <= doc.numPages; i++) {
    const p = await doc.getPage(i);
    const tc = await p.getTextContent();
    pages.push(buildLinesFromItems(tc.items));
  }
  let info = {};
  try {
    info = (await doc.getMetadata()).info || {};
  } catch { /* ignore */ }
  return { numpages: doc.numPages, pages, info, engine: 'pdfjs-dist' };
}

async function _pdfParseEngine(buf) {
  let pdfParse;
  try {
    pdfParse = require('pdf-parse');
  } catch {
    return null;
  }
  const rawPages = [];
  const data = await pdfParse(buf, {
    pagerender(pageData) {
      return pageData
        .getTextContent({ normalizeWhitespace: false, disableCombineTextItems: true })
        .then((tc) => {
          const lines = buildLinesFromItems(tc.items || []);
          const t = lines.map((l) => l.text).join('\n');
          rawPages.push(lines);
          return t + '\n';
        })
        .catch(() => {
          rawPages.push([]);
          return '';
        });
    },
  });
  if (!rawPages.length) {
    // 最原始的降级：整页当一行
    rawPages.push(String(data.text || '').split(/\r?\n/).map((t) => ({ text: t, paraBreak: true })));
  }
  return { numpages: data.numpages || rawPages.length, pages: rawPages, info: data.info || {}, engine: 'pdf-parse' };
}

/**
 * @returns {Promise<{numpages:number, pages:Array<Array<{text:string,paraBreak:boolean}>>, text:string, info:object, engine:string}>}
 */
async function extractPdf(filePath) {
  const buf = fs.readFileSync(filePath);
  let lastErr = null;
  // 可用环境变量强制指定引擎：SCHOLARDESK_PDF_ENGINE=pdfparse
  const engines =
    process.env.SCHOLARDESK_PDF_ENGINE === 'pdfparse'
      ? [_pdfParseEngine, _pdfjsEngine]
      : [_pdfjsEngine, _pdfParseEngine];
  for (const engine of engines) {
    try {
      const r = await engine(buf);
      const hasText = r && r.pages.some((pg) => pg.some((l) => l.text && l.text.trim()));
      if (hasText) {
        return { ...r, text: r.pages.map((pg) => pg.map((l) => l.text).join('\n')).join('\n') };
      }
      if (r) lastErr = new Error(`${r.engine} 未提取到文本`);
    } catch (e) {
      lastErr = e;
    }
  }
  throw new Error(
    `无法提取 PDF 文本${lastErr ? '（' + lastErr.message + '）' : ''}。常见原因：扫描件/图片型 PDF（需 OCR），` +
      `或未嵌入的中文字体。可改用「导入文本」粘贴全文。请确认已 npm install（pdfjs-dist 或 pdf-parse）。`
  );
}

// ---------------------------------------------------------------- 学术结构识别

const SECTION_PATTERNS = [
  /^\s*(\d+(?:\.\d+)*)\s*[:.、]?\s+(.{2,60})$/, // 1 Introduction / 2.3 实验方法
  /^\s*(abstract|摘要|introduction|引言|related work|相关工作|method(s|ology)?|方法|experiment(s|al setup)?|实验|result(s)?|结果|discussion|讨论|conclusion(s)?|结论|future work|展望|acknowledg(e)?ment(s)?|致谢|reference(s)?|参考文献|appendix|附录)\s*$/i,
  /^\s*[IVXLC]+\.\s+.{2,60}$/, // IV. DISCUSSION
];

function isHeading(line) {
  const t = String(line || '').trim();
  if (!t || t.length > 80) return false;
  for (const re of SECTION_PATTERNS) if (re.test(t)) return true;
  // 无编号的短标题行（全大写 / 全中文、无句末标点）
  if (t.length <= 60 && !/[.;。：,]$/.test(t) && t.split(/\s+/).length <= 8) {
    if (/^[A-Z][A-Z\s\-–:]+$/.test(t)) return true;
    if (/^[\u4e00-\u9fff]{2,12}$/.test(t) && !/^(本文|我们|该|由于|因此|此外|然而|目前|随着)/.test(t)) return true;
  }
  return false;
}

/** 公式 / 表格 / 纯符号行：翻译与改写时应原样保留 */
const FORMULA_HINT = /(\$[^$]+\$)|(\\begin\{(equation|align|math|tabular)\})|(\\[a-zA-Z]+\{)|(∑|∫|≈|≤|≥|±|α|β|γ|θ|λ|μ|σ|∈|→|×|÷)/;

function looksFormula(line) {
  const t = String(line || '').trim();
  if (!t) return false;
  if (FORMULA_HINT.test(t)) return true;
  const letters = (t.match(/[A-Za-z\u4e00-\u9fff]/g) || []).length;
  const symbols = (t.match(/[=+\-*/^_(){}\[\]<>|]/g) || []).length;
  return symbols > 3 && letters / (symbols + 1) < 1.2;
}

function cleanLine(text) {
  let l = String(text || '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').replace(/\s+/g, ' ').trim();
  if (/^\d{1,4}$/.test(l)) return ''; // 纯页码
  if (/^(arxiv:|preprint|accepted at|under review|to appear)/i.test(l) && l.length < 70) return ''; // 页眉
  return l;
}

/**
 * 把页面行数组切成带结构的段落（segments）。
 * @param {Array<Array<{text:string,paraBreak:boolean}>>} pages
 * @returns {{segments:Array, meta:object}}
 */
function segmentPages(pages) {
  const segments = [];
  let section = '正文';
  let buf = [];
  let startPage = 1;

  const flush = (kind) => {
    if (!buf.length) return;
    let text = buf.join(' ').replace(/\s+/g, ' ').trim();
    text = text.replace(/([\u4e00-\u9fff])\s+([\u4e00-\u9fff])/g, '$1$2');
    if (text.length >= 2) {
      segments.push({
        id: 'seg-' + crypto.createHash('md5').update(text + startPage + segments.length).digest('hex').slice(0, 10),
        page: startPage,
        section,
        text,
        kind: kind || 'paragraph',
      });
    }
    buf = [];
  };

  pages.forEach((lines, pageIdx) => {
    const pageNo = pageIdx + 1;
    lines.forEach((ln, i) => {
      let text = cleanLine(ln.text);
      if (!text) return;
      const prev = lines[i - 1];
      const next = lines[i + 1];

      if (isHeading(text)) {
        flush();
        section = text;
        startPage = pageNo;
        segments.push({
          id: 'head-' + crypto.createHash('md5').update(text + pageNo + segments.length).digest('hex').slice(0, 10),
          page: pageNo,
          section: text,
          text,
          kind: 'heading',
        });
        return;
      }
      if (looksFormula(text)) {
        flush();
        segments.push({
          id: 'fml-' + crypto.createHash('md5').update(text + pageNo + segments.length).digest('hex').slice(0, 10),
          page: pageNo,
          section,
          text,
          kind: 'formula',
        });
        return;
      }

      // 英文断字换行：atten-\ntion -> attention
      const isHyphenBreak = /[a-z\u00e0-\u024f]-$/.test(text) && next && /^[a-z]/.test(cleanLine(next.text) || 'x');
      if (isHyphenBreak) {
        buf.push(text.slice(0, -1));
        return;
      }

      if (!buf.length) startPage = pageNo;
      buf.push(text);

      const joined = buf.join(' ');
      const endsSentence = /[.。!?；]$/.test(text) || /["')\]]?$/.test(text) && /[.。!?]["')\]]?$/.test(text);
      // 段落结束条件：句末标点 + 长度够 +（下一行是空行/缩进/或已足够长）
      if (endsSentence && joined.length > 60 && (!next || next.paraBreak || joined.length > 400)) flush();
      else if (joined.length > 900) flush();
    });
  });
  flush();

  const firstPageText = (pages[0] || []).map((l) => l.text).join('\n');
  return { segments, meta: guessMeta(firstPageText, segments) };
}

/** 从首页猜标题 / 作者 / 年份（猜不出来就交给用户手改） */
function guessMeta(firstPage, segments) {
  const lines = String(firstPage || '').split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  let title = '';
  let authors = '';
  let year = null;

  for (let i = 0; i < Math.min(lines.length, 14); i++) {
    const l = lines[i];
    if (!title && l.length >= 8 && l.length <= 200 && !/^(arxiv|preprint|published)/i.test(l)) {
      title = l;
      continue;
    }
    if (title && !authors && /[,，;]|\band\b|@|†|\*/.test(l) && l.length < 200 && !/abstract|摘要|university|univ\./i.test(l)) {
      authors = l;
    }
    const m = l.match(/\b(19|20)\d{2}\b/);
    if (m && !year) year = Number(m[0]);
  }
  if (!year) {
    const all = (segments || []).map((s) => s.text).join(' ');
    const m = all.match(/\b(19|20)\d{2}\b/);
    if (m) year = Number(m[0]);
  }
  return { title: title || '', authors: authors || '', year: year || null };
}

/**
 * 段落 -> 检索/喂模型用的 chunk（带尾部重叠，避免切断语义）。
 */
function buildChunks(segments, { maxChars = 900, overlapChars = 120 } = {}) {
  const chunks = [];
  let cur = [];
  let curLen = 0;

  const push = () => {
    if (!cur.length) return;
    const text = cur.map((c) => c.text).join('\n').trim();
    if (text.length >= 20) {
      chunks.push({
        id: 'chk-' + crypto.createHash('md5').update(text + chunks.length).digest('hex').slice(0, 12),
        section: cur[0].section,
        page: cur[0].page,
        text,
      });
    }
    const tail = text.slice(-overlapChars);
    cur = tail ? [{ section: cur[cur.length - 1].section, page: cur[cur.length - 1].page, text: tail }] : [];
    curLen = tail.length;
  };

  for (const s of segments) {
    if (s.kind === 'heading') {
      push();
      continue;
    }
    if (s.kind === 'formula') {
      cur.push({ section: s.section, page: s.page, text: '[公式] ' + s.text });
      curLen += s.text.length;
      continue;
    }
    if (curLen + s.text.length > maxChars && curLen > 0) push();
    cur.push({ section: s.section, page: s.page, text: s.text });
    curLen += s.text.length;
  }
  push();
  return chunks;
}

/** 完整入库：文件 -> {meta, segments, chunks} */
async function parsePdfFile(filePath) {
  const stat = fs.statSync(filePath);
  const { numpages, pages, info } = await extractPdf(filePath);
  const { segments, meta } = segmentPages(pages);
  const chunks = buildChunks(segments);

  let title = (info && info.Title) || meta.title;
  if (!title || /^(untitled|anonymous|\(anonymous\)|未识别)$/i.test(title)) {
    title = path.basename(filePath, path.extname(filePath)).replace(/[_]+/g, ' ');
  }
  return {
    file: filePath,
    fileName: path.basename(filePath),
    sizeBytes: stat.size,
    numpages,
    title,
    authors: meta.authors,
    year: meta.year,
    segments,
    chunks,
  };
}

module.exports = {
  extractPdf,
  buildLinesFromItems,
  segmentPages,
  buildChunks,
  parsePdfFile,
  isHeading,
  looksFormula,
};
