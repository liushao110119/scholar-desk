'use strict';
/**
 * 本机配置与凭据存储。
 * API Key 用 Electron 内置 safeStorage 加密后落盘（不引入 keytar，避免编译依赖）；
 * 非 Electron 环境（跑单元测试时）自动降级为明文 + 提示。
 */

const fs = require('fs');
const path = require('path');

let safeStorage = null;
try {
  safeStorage = require('electron').safeStorage;
} catch { /* 纯 Node 环境 */ }

const DEFAULT_CONFIG = {
  version: 1,
  provider: null, // 当前选中的供应商 id（PRESETS 里的 key）
  providers: {}, // { [id]: { baseUrl, model, embeddingModel, pricePerMTok:{in,out}, apiKeyEnc|apiKey } }
  features: {
    useEmbeddingRerank: false, // 关闭=纯 BM25；开启=调用 /embeddings 做语义重排
    translateBatchChars: 1600,
    retrievalTopK: 12,
    citationStyle: 'gb7714', // gb7714 | bibtex | apa
  },
  ui: { theme: 'light', sidebar: 'library' },
};

class Store {
  constructor(dir) {
    this.dir = dir || path.join(process.cwd(), '.scholar-desk');
    fs.mkdirSync(this.dir, { recursive: true });
    this.configPath = path.join(this.dir, 'config.json');
    this.config = this._load();
  }

  _load() {
    let cfg;
    try {
      cfg = JSON.parse(fs.readFileSync(this.configPath, 'utf8'));
    } catch {
      cfg = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
    }
    // 向后兼容：补齐缺失字段
    const merged = { ...DEFAULT_CONFIG, ...cfg };
    merged.features = { ...DEFAULT_CONFIG.features, ...(cfg.features || {}) };
    merged.ui = { ...DEFAULT_CONFIG.ui, ...(cfg.ui || {}) };
    merged.providers = cfg.providers || {};
    return merged;
  }

  save() {
    try {
      fs.chmodSync(this.dir, 0o700);
    } catch { /* Windows 无 chmod */ }
    fs.writeFileSync(this.configPath, JSON.stringify(this.config, null, 2), 'utf8');
    try {
      fs.chmodSync(this.configPath, 0o600);
    } catch { /* ignore */ }
  }

  get(pathStr, fallback = undefined) {
    const parts = pathStr.split('.');
    let cur = this.config;
    for (const p of parts) {
      if (cur == null || typeof cur !== 'object') return fallback;
      cur = cur[p];
    }
    return cur === undefined ? fallback : cur;
  }

  set(pathStr, value) {
    const parts = pathStr.split('.');
    let cur = this.config;
    for (let i = 0; i < parts.length - 1; i++) {
      if (typeof cur[parts[i]] !== 'object' || cur[parts[i]] === null) cur[parts[i]] = {};
      cur = cur[parts[i]];
    }
    cur[parts[parts.length - 1]] = value;
    this.save();
    return value;
  }

  // ---------------------------------------------------- 凭据加密

  setApiKey(providerId, key) {
    const enc = this._encrypt(key);
    const p = this.config.providers[providerId] || (this.config.providers[providerId] = {});
    if (enc) {
      p.apiKeyEnc = enc;
      delete p.apiKey;
    } else {
      p.apiKey = key;
      delete p.apiKeyEnc;
    }
    this.save();
  }

  getApiKey(providerId) {
    const p = this.config.providers[providerId];
    if (!p) return '';
    if (p.apiKeyEnc) {
      try {
        return safeStorage.decryptString(Buffer.from(p.apiKeyEnc, 'base64'));
      } catch {
        return '';
      }
    }
    return p.apiKey || '';
  }

  _encrypt(plain) {
    if (!plain) return null;
    try {
      if (safeStorage && safeStorage.isEncryptionAvailable()) {
        return safeStorage.encryptString(String(plain)).toString('base64');
      }
    } catch { /* 降级 */ }
    return null;
  }

  /** 交给调用方（providers.js）的完整连接配置 */
  getProviderConfig(providerId) {
    const p = this.config.providers[providerId] || {};
    const preset = require('./providers').PRESETS[providerId] || {};
    return {
      baseUrl: p.baseUrl || preset.baseUrl || '',
      apiKey: this.getApiKey(providerId),
      model: p.model || (preset.models || [])[0] || '',
      embeddingModel: p.embeddingModel || '',
      pricePerMTok: p.pricePerMTok || preset.price || { in: 0, out: 0 },
    };
  }

  setProviderOptions(providerId, patch) {
    const p = this.config.providers[providerId] || (this.config.providers[providerId] = {});
    for (const [k, v] of Object.entries(patch)) {
      if (k === 'apiKey') {
        this.setApiKey(providerId, v);
      } else {
        p[k] = v;
      }
    }
    this.save();
    return p;
  }
}

module.exports = { Store, DEFAULT_CONFIG };
