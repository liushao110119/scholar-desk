'use strict';
/**
 * 零依赖的 BM25 倒排索引。
 *
 * 为什么不用 SQLite FTS5 / better-sqlite3：那需要 node-gyp 本地编译，
 * 很多同学的机器上装不上（缺 Python / C++ 工具链）。对个人知识库
 * （几百篇 PDF、数万 chunk）来说，纯 JS 的 BM25 完全够用，且秒级构建。
 */

const fs = require('fs');
const path = require('path');

// ---------------------------------------------------------------- 分词

const CJK = /[㐀-䶿一-鿿぀-ヿ가-힯]/;

/**
 * 中英混排分词：
 *  - 拉丁文/数字 -> 按词切分（保留化学式、型号、单位）
 *  - CJK -> unigram + bigram（不依赖分词库也能有不错的召回）
 */
function tokenize(text) {
  const s = String(text || '').toLowerCase();
  const out = [];
  // 先按空白/标点切成片段
  const pieces = s.split(/[^\p{L}\p{N}+#.\-_/]+/u);
  for (const piece of pieces) {
    if (!piece) continue;
    // 拆成 CJK 段与非 CJK 段
    const runs = piece.match(/[㐀-䶿一-鿿぀-ヿ가-힯]+|[^\u4e00-\u9fff]+/g) || [];
    for (const run of runs) {
      if (CJK.test(run[0])) {
        if (run.length === 1) {
          out.push(run);
        } else {
          for (let i = 0; i < run.length - 1; i++) out.push(run.slice(i, i + 2));
          for (let i = 0; i < run.length; i++) out.push(run[i]); // unigram 兜底长尾
        }
      } else {
        const words = run.split(/[^a-z0-9+#.\-_/]+/i).filter(Boolean);
        for (const w of words) {
          if (w.length > 1 || /\d/.test(w)) out.push(w);
        }
      }
    }
  }
  return out;
}

// ---------------------------------------------------------------- 索引

class BM25Index {
  constructor(opts = {}) {
    this.k1 = opts.k1 ?? 1.2;
    this.b = opts.b ?? 0.75;
    /** @type {Map<string, Map<string, number>>} term -> (docId -> tf) */
    this.postings = new Map();
    /** @type {Map<string, {len:number, text:string}>} */
    this.docs = new Map();
    this.avgdl = 0;
  }

  get size() {
    return this.docs.size;
  }

  add(docId, text) {
    this.remove(docId);
    const tokens = tokenize(text);
    const tf = new Map();
    for (const t of tokens) tf.set(t, (tf.get(t) || 0) + 1);
    for (const [term, n] of tf) {
      let p = this.postings.get(term);
      if (!p) {
        p = new Map();
        this.postings.set(term, p);
      }
      p.set(docId, n);
    }
    this.docs.set(docId, { len: tokens.length, text: String(text || '') });
    this._recomputeAvgdl();
  }

  remove(docId) {
    if (!this.docs.has(docId)) return false;
    // 从所有倒排链摘掉（chunk 数量级下可接受；批量删除用 rebuild）
    for (const [term, p] of this.postings) {
      if (p.delete(docId) && p.size === 0) this.postings.delete(term);
    }
    this.docs.delete(docId);
    this._recomputeAvgdl();
    return true;
  }

  clear() {
    this.postings.clear();
    this.docs.clear();
    this.avgdl = 0;
  }

  _recomputeAvgdl() {
    if (this.docs.size === 0) {
      this.avgdl = 0;
      return;
    }
    let total = 0;
    for (const d of this.docs.values()) total += d.len;
    this.avgdl = total / this.docs.size;
  }

  _idf(term) {
    const p = this.postings.get(term);
    if (!p) return 0;
    const N = this.docs.size;
    const df = p.size;
    return Math.log(1 + (N - df + 0.5) / (df + 0.5));
  }

  /**
   * 检索。返回 [{id, score}]，已按分数降序。
   * @param {string} query
   * @param {number} topK
   * @param {Set<string>} [filterIds] 可选：只在子集内检索（如限定某几篇文献）
   */
  search(query, topK = 20, filterIds = null) {
    const qterms = tokenize(query);
    if (!qterms.length || !this.docs.size) return [];
    const uniq = [...new Set(qterms)];
    const scores = new Map();

    for (const term of uniq) {
      const p = this.postings.get(term);
      if (!p) continue;
      const idf = this._idf(term);
      if (idf <= 0) continue;
      for (const [docId, tf] of p) {
        if (filterIds && !filterIds.has(docId)) continue;
        const dl = this.docs.get(docId)?.len || 0;
        const norm = tf * (this.k1 + 1) / (tf + this.k1 * (1 - this.b + this.b * (dl / (this.avgdl || 1))));
        scores.set(docId, (scores.get(docId) || 0) + idf * norm);
      }
    }
    return [...scores.entries()]
      .map(([id, score]) => ({ id, score }))
      .sort((a, b) => b.score - a.score)
      .slice(0, topK);
  }

  /** 取回原文（用于拼装引用上下文） */
  getText(docId) {
    return this.docs.get(docId)?.text || '';
  }

  // ------------------------------------------------------- 持久化

  toJSON() {
    return {
      version: 1,
      k1: this.k1,
      b: this.b,
      docs: [...this.docs].map(([id, v]) => [id, v.len]),
      postings: [...this.postings].map(([t, p]) => [t, [...p]]),
    };
  }

  static fromJSON(data) {
    const idx = new BM25Index({ k1: data.k1, b: data.b });
    for (const [id, len] of data.docs || []) idx.docs.set(id, { len, text: '' });
    for (const [t, p] of data.postings || []) idx.postings.set(t, new Map(p));
    idx._recomputeAvgdl();
    return idx;
  }

  save(file) {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(this.toJSON()), 'utf8');
  }

  static load(file) {
    if (!fs.existsSync(file)) return new BM25Index();
    try {
      return BM25Index.fromJSON(JSON.parse(fs.readFileSync(file, 'utf8')));
    } catch {
      return new BM25Index();
    }
  }
}

module.exports = { BM25Index, tokenize };
