'use strict';
/**
 * 保真全文对照翻译。
 *
 * 难点从来不是"翻译"，而是**不把公式、图表编号、参考文献翻烂**，
 * 并且多篇文献之间术语要一致。这里用三个手段解决：
 *  1. 公式/参考文献/纯符号段落在解析阶段就标记为不翻译，原样搬运；
 *  2. 分批翻译时携带并持续累积术语表（glossary），保证前后一致；
 *  3. 段落级缓存，同一段只翻译一次 —— 重翻、增量更新都省钱。
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { SYSTEM_TRANSLATOR, translatePrompt } = require('../shared/prompts');
const { chat } = require('./providers');

const NO_TRANSLATE_KINDS = new Set(['formula']);

function hashText(t) {
  return crypto.createHash('md5').update(t).digest('hex').slice(0, 16);
}

/** 从模型输出里尽力抠出译文数组（JSON 优先，行号格式兜底） */
function parseTranslationResponse(raw) {
  let text = String(raw || '').trim();
  text = text.replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start >= 0 && end > start) {
    const slice = text.slice(start, end + 1);
    try {
      const json = JSON.parse(slice);
      if (Array.isArray(json.items)) {
        const map = new Map();
        for (const it of json.items) if (it && it.t != null) map.set(Number(it.i), String(it.t));
        return { map, glossary: json.glossary && typeof json.glossary === 'object' ? json.glossary : {} };
      }
      if (Array.isArray(json)) {
        const map = new Map();
        json.forEach((it, idx) => {
          if (typeof it === 'string') map.set(idx + 1, it);
          else if (it && it.t != null) map.set(Number(it.i ?? idx + 1), String(it.t));
        });
        return { map, glossary: {} };
      }
    } catch { /* 落到行号解析 */ }
  }
  // 兜底：按 "1. xxx" / "1\txxx" 行解析
  const map = new Map();
  for (const line of text.split(/\r?\n/)) {
    const m = line.match(/^\s*(\d+)\s*[.、)）\t:：]\s*(.+)$/);
    if (m) map.set(Number(m[1]), m[2].trim());
  }
  return { map, glossary: {} };
}

/** 把段落切成不超过 maxChars 的批次，不切断单个段落 */
function makeBatches(items, maxChars) {
  const batches = [];
  let cur = [];
  let len = 0;
  for (const it of items) {
    if (cur.length && len + it.text.length > maxChars) {
      batches.push(cur);
      cur = [];
      len = 0;
    }
    cur.push(it);
    len += it.text.length;
  }
  if (cur.length) batches.push(cur);
  return batches;
}

/**
 * 翻译一篇文献的 segments。
 * @param {object} params
 * @param {Array} params.segments pdf.js 输出的段落（含 kind/page/section/text）
 * @param {object} params.cfg Provider 配置（baseUrl/apiKey/model/pricePerMTok）
 * @param {string} params.docId 用于缓存
 * @param {string} params.cacheDir
 * @param {string} [params.targetLang]
 * @param {(p:{current:number,total:number,phase:string})=>void} [params.onProgress]
 * @param {()=>boolean} [params.shouldStop] 返回 true 则中断
 */
async function translateDocument(params) {
  const {
    segments,
    cfg,
    docId = 'unknown',
    cacheDir,
    targetLang = 'zh',
    onProgress,
    shouldStop,
    batchChars = 1600,
    usageHook,
  } = params;

  const cacheFile = cacheDir ? path.join(cacheDir, `translate-${docId}-${targetLang}.json`) : null;
  let cache = {};
  if (cacheFile && fs.existsSync(cacheFile)) {
    try {
      cache = JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
    } catch {
      cache = {};
    }
  }

  const toTranslate = [];
  const results = [];
  for (const s of segments) {
    const key = hashText(s.text);
    if (NO_TRANSLATE_KINDS.has(s.kind) || /^\[\d+\]|^参考文献|^References/i.test(s.text.trim())) {
      results.push({ ...s, translated: s.text, skipped: true, hash: key });
      continue;
    }
    if (cache[key]) {
      results.push({ ...s, translated: cache[key], cached: true, hash: key });
      continue;
    }
    toTranslate.push({ ...s, hash: key });
  }

  const batches = makeBatches(toTranslate, batchChars);
  let glossary = cache.__glossary || {};
  let done = 0;
  const errors = [];

  for (let bi = 0; bi < batches.length; bi++) {
    if (shouldStop && shouldStop()) break;
    const batch = batches[bi];
    const prompt = translatePrompt(batch, glossary, targetLang);
    try {
      const r = await chat(
        cfg,
        [
          { role: 'system', content: SYSTEM_TRANSLATOR },
          { role: 'user', content: prompt },
        ],
        { temperature: 0.2, maxTokens: Math.min(4000, 200 + batch.reduce((n, b) => n + b.text.length, 0) * 2) }
      );
      usageHook?.({ usage: r.usage, feature: 'translate', batch: bi });
      const { map, glossary: g } = parseTranslationResponse(r.content);
      if (g && typeof g === 'object') glossary = { ...glossary, ...g };
      batch.forEach((item, idx) => {
        const t = map.get(idx + 1);
        if (t && t.trim()) {
          results.push({ ...item, translated: t.trim() });
          cache[item.hash] = t.trim();
        } else {
          errors.push({ segment: item.id, reason: '未解析到译文' });
          results.push({ ...item, translated: '', error: true });
        }
      });
    } catch (e) {
      errors.push({ batch: bi, reason: e.message });
      batch.forEach((item) => results.push({ ...item, translated: '', error: true }));
    }
    done += batch.length;
    onProgress?.({ current: done, total: toTranslate.length, phase: `翻译中 ${bi + 1}/${batches.length}` });
  }

  if (cacheFile) {
    fs.mkdirSync(path.dirname(cacheFile), { recursive: true });
    fs.writeFileSync(cacheFile, JSON.stringify({ ...cache, __glossary: glossary }, null, 2), 'utf8');
  }

  // 按原顺序还原
  const order = new Map(segments.map((s, i) => [s.id, i]));
  const ordered = results.sort((a, b) => (order.get(a.id) ?? 0) - (order.get(b.id) ?? 0));
  return { segments: ordered, glossary, errors, translatedCount: toTranslate.length };
}

/** 生成段落级中英对照 Markdown */
function toBilingualMarkdown(segments, meta = {}, mode = 'paragraph') {
  const head = `# ${meta.title || '译文'}\n\n${meta.authors ? '> ' + meta.authors + '\n' : ''}${meta.year ? '> ' + meta.year + '\n' : ''}\n`;
  const body = segments
    .map((s) => {
      if (s.kind === 'heading') {
        return `\n## ${s.translated || s.text}\n\n> 原文：${s.text}\n`;
      }
      if (mode === 'paragraph') {
        return `${s.translated || '（未翻译）'}\n\n<!-- 原文 -->\n> ${s.text}\n`;
      }
      // table 模式交给 HTML
      return '';
    })
    .join('\n');
  return head + body;
}

/** 生成左右对照 HTML（公式与编号原样保留） */
function toBilingualHTML(segments, meta = {}) {
  const rows = segments
    .filter((s) => s.kind !== 'heading')
    .map(
      (s) => `<tr class="${s.kind}">
  <td class="src"><span class="pno">p.${s.page}</span>${_escape(s.text)}</td>
  <td class="dst">${s.translated ? _escape(s.translated) : '<em class="miss">（未翻译）</em>'}</td>
</tr>`
    )
    .join('\n');
  return `<!doctype html><html lang="zh"><head><meta charset="utf-8">
<title>${_escape(meta.title || '对照译文')}</title>
<style>
body{font-family:-apple-system,"Segoe UI","Microsoft YaHei",serif;margin:0;background:#faf9f7;color:#1a1a1a}
header{padding:18px 24px;border-bottom:1px solid #e5e2dc;background:#fff}
h1{margin:0 0 6px;font-size:19px}
.meta{color:#6b6b6b;font-size:13px}
table{border-collapse:collapse;width:100%;table-layout:fixed}
td{vertical-align:top;padding:10px 14px;border-bottom:1px solid #eeeae4;font-size:14.5px;line-height:1.75;word-break:break-word}
td.src{background:#fff;border-right:1px solid #eeeae4;color:#555}
td.dst{background:#fdfcfa}
.pno{display:inline-block;margin-right:6px;font-size:11px;color:#a8a29a}
.miss{color:#b91c1c;font-style:normal}
@media print{body{background:#fff}}
</style></head><body>
<header><h1>${_escape(meta.title || '对照译文')}</h1>
<div class="meta">${_escape(meta.authors || '')} ${meta.year ? '· ' + meta.year : ''}</div></header>
<table>${rows}</table></body></html>`;
}

function _escape(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

module.exports = {
  translateDocument,
  parseTranslationResponse,
  makeBatches,
  toBilingualMarkdown,
  toBilingualHTML,
  hashText,
};
