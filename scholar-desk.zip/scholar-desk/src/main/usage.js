'use strict';
/**
 * 用量与成本统计 —— 自己接算力最大的好处就是"花的每一分钱都看得见"。
 * 每次调用记录 token 数，按各供应商价格表折算，按日/按功能/按供应商汇总。
 */

const fs = require('fs');
const path = require('path');

class Usage {
  constructor(dataDir) {
    this.dir = dataDir;
    fs.mkdirSync(this.dir, { recursive: true });
    this.file = path.join(this.dir, 'usage.json');
    /** @type {Array} */
    this.records = [];
    this._load();
  }

  _load() {
    try {
      this.records = JSON.parse(fs.readFileSync(this.file, 'utf8')).records || [];
    } catch {
      this.records = [];
    }
  }

  _save() {
    // 只保留最近 20000 条，避免文件无限膨胀
    if (this.records.length > 20000) this.records = this.records.slice(-20000);
    fs.writeFileSync(this.file, JSON.stringify({ version: 1, records: this.records }, null, 2), 'utf8');
  }

  /**
   * @param {{provider:string, model:string, feature:string, usage:object, pricePerMTok?:{in:number,out:number}}} r
   */
  record(r) {
    const prompt = r.usage?.prompt_tokens || 0;
    const completion = r.usage?.completion_tokens || 0;
    const price = r.pricePerMTok || { in: 0, out: 0 };
    const cost = (prompt / 1e6) * (price.in || 0) + (completion / 1e6) * (price.out || 0);
    const rec = {
      ts: Date.now(),
      provider: r.provider || 'unknown',
      model: r.model || '',
      feature: r.feature || 'chat',
      promptTokens: prompt,
      completionTokens: completion,
      totalTokens: prompt + completion,
      estimated: !!r.usage?.estimated,
      costYuan: Number(cost.toFixed(6)),
    };
    this.records.push(rec);
    this._save();
    return rec;
  }

  summary({ days = 30 } = {}) {
    const since = Date.now() - days * 86400000;
    const recent = this.records.filter((r) => r.ts >= since);
    const byProvider = {};
    const byFeature = {};
    const byDay = {};
    let cost = 0;
    let tokens = 0;
    for (const r of recent) {
      cost += r.costYuan;
      tokens += r.totalTokens;
      byProvider[r.provider] = (byProvider[r.provider] || 0) + r.costYuan;
      byFeature[r.feature] = (byFeature[r.feature] || 0) + r.costYuan;
      const d = new Date(r.ts).toISOString().slice(0, 10);
      byDay[d] = (byDay[d] || 0) + r.costYuan;
    }
    return {
      days,
      calls: recent.length,
      totalTokens: tokens,
      totalCostYuan: Number(cost.toFixed(4)),
      byProvider: _round(byProvider),
      byFeature: _round(byFeature),
      byDay: _round(byDay),
    };
  }

  clear() {
    this.records = [];
    this._save();
  }
}

function _round(obj) {
  const out = {};
  for (const [k, v] of Object.entries(obj)) out[k] = Number(v.toFixed(4));
  return out;
}

module.exports = { Usage };
