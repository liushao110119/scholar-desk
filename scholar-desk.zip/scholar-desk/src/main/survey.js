'use strict';
/**
 * 综述生成 / 学术写作辅助 / 知识库问答。
 *
 * 共同机制【证据锚点】：
 *   检索到的 chunk 编号成 [1]..[n]，模型只能引用这些编号；
 *   输出时把编号还原成"文献名 + 页码 + 原文片段"，用户可逐条核对。
 *   这样从机制上压制幻觉引用 —— 编不出编号，就会露馅。
 */

const {
  SYSTEM_QA,
  SYSTEM_SURVEY,
  qaPrompt,
  surveyPrompt,
  outlinePrompt,
  ideaPrompt,
} = require('../shared/prompts');
const { chat, chatStream } = require('./providers');

/** 命中结果 -> 带编号的证据表 */
function buildEvidence(hits) {
  return hits.map((h, i) => ({
    n: i + 1,
    chunkId: h.chunkId,
    docId: h.docId,
    title: h.title,
    authors: h.authors,
    year: h.year,
    section: h.section,
    page: h.page,
    excerpt: h.text.length > 400 ? h.text.slice(0, 400) + '…' : h.text,
    score: h.score,
  }));
}

/** 多查询合并检索：每个检索词各取 topK，按分数重排去重 */
async function retrieveEvidences(library, queries, { topK = 12, docIds, rerank, embedFn } = {}) {
  const seen = new Map();
  for (const q of queries) {
    if (!q || !q.trim()) continue;
    const hits = await library.search(q, { topK, docIds, rerank, embedFn });
    for (const h of hits) {
      const prev = seen.get(h.chunkId);
      if (!prev || h.score > prev.score) seen.set(h.chunkId, h);
    }
  }
  return [...seen.values()].sort((a, b) => b.score - a.score).slice(0, topK);
}

function extractJSON(text) {
  let t = String(text || '').trim().replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
  const s = t.indexOf('{');
  const e = t.lastIndexOf('}');
  if (s >= 0 && e > s) t = t.slice(s, e + 1);
  try {
    return JSON.parse(t);
  } catch {
    return null;
  }
}

/**
 * 知识库问答。
 * @returns {Promise<{answer:string, evidence:Array, usage:object}>}
 */
async function answerQuestion(params) {
  const { library, cfg, question, docIds, topK = 10, rerank, embedFn, usageHook, onDelta } = params;
  const hits = await retrieveEvidences(library, [question], { topK, docIds, rerank, embedFn });
  const evidence = buildEvidence(hits);
  if (!evidence.length) {
    return {
      answer: '知识库中没有检索到相关片段。请确认：① 已导入相关 PDF；② 提问用了文献中实际出现的术语（可换同义词再试）。',
      evidence: [],
      usage: null,
    };
  }
  const messages = [
    { role: 'system', content: SYSTEM_QA },
    { role: 'user', content: qaPrompt(question, evidence) },
  ];
  if (onDelta) {
    const r = await chatStream(cfg, messages, onDelta, { temperature: 0.2 });
    usageHook?.({ usage: r.usage, feature: 'qa' });
    return { answer: r.content, evidence, usage: r.usage };
  }
  const r = await chat(cfg, messages, { temperature: 0.2 });
  usageHook?.({ usage: r.usage, feature: 'qa' });
  return { answer: r.content, evidence, usage: r.usage };
}

/**
 * 生成综述。
 * @returns {Promise<{title:string, sections:Array, evidence:Array, markdown:string, usage:object}>}
 */
async function generateSurvey(params) {
  const {
    library,
    cfg,
    topic,
    docIds,
    topK = 12,
    rerank,
    embedFn,
    usageHook,
    onProgress,
    shouldStop,
    lang = 'zh',
  } = params;

  onProgress?.({ phase: '检索证据', current: 0, total: 100 });
  const pool = await retrieveEvidences(library, [topic], { topK: Math.min(topK * 2, 24), docIds, rerank, embedFn });
  if (!pool.length) throw new Error('没有检索到任何相关文献片段，无法生成综述。请先导入文献或换个主题词。');

  onProgress?.({ phase: '设计大纲', current: 10, total: 100 });
  const outlineRes = await chat(
    cfg,
    [
      { role: 'system', content: SYSTEM_SURVEY },
      { role: 'user', content: outlinePrompt(topic, buildEvidence(pool), lang) },
    ],
    { temperature: 0.4 }
  );
  usageHook?.({ usage: outlineRes.usage, feature: 'survey-outline' });

  let sectionsPlan = extractJSON(outlineRes.content)?.sections;
  if (!Array.isArray(sectionsPlan) || !sectionsPlan.length) {
    // 大纲解析失败 -> 用默认结构兜底，保证流程不中断
    sectionsPlan = [
      { title: '1 引言', goal: '界定问题与研究意义', queries: [topic] },
      { title: '2 方法分类', goal: '梳理主流技术路线', queries: [`${topic} method`, `${topic} approach`] },
      { title: '3 结果对比', goal: '横向比较关键指标', queries: [`${topic} results`, `${topic} evaluation`] },
      { title: '4 局限与展望', goal: '指出不足与未来方向', queries: [`${topic} limitation`, `${topic} future work`] },
    ];
  }

  const sections = [];
  const allEvidence = new Map();
  for (let i = 0; i < sectionsPlan.length; i++) {
    if (shouldStop && shouldStop()) break;
    const plan = sectionsPlan[i];
    onProgress?.({
      phase: `撰写：${plan.title}`,
      current: 10 + Math.round(((i + 1) / sectionsPlan.length) * 85),
      total: 100,
    });
    const queries = Array.isArray(plan.queries) && plan.queries.length ? plan.queries : [topic];
    const hits = await retrieveEvidences(library, queries, { topK, docIds, rerank, embedFn });
    const ev = buildEvidence(hits.length ? hits : pool.slice(0, topK));
    ev.forEach((e) => allEvidence.set(e.n + '@' + (e.chunkId || ''), e));

    const r = await chat(
      cfg,
      [
        { role: 'system', content: SYSTEM_SURVEY },
        { role: 'user', content: surveyPrompt(topic, ev, `${plan.title}｜本节目标：${plan.goal || ''}`, lang) },
      ],
      { temperature: 0.35 }
    );
    usageHook?.({ usage: r.usage, feature: 'survey-section' });
    sections.push({ title: plan.title, goal: plan.goal || '', content: r.content.trim(), evidence: ev });
  }

  const evidenceList = [...allEvidence.values()].sort((a, b) => a.n - b.n);
  return {
    title: topic,
    sections,
    evidence: evidenceList,
    markdown: toSurveyMarkdown(topic, sections, evidenceList),
  };
}

function toSurveyMarkdown(topic, sections, evidence) {
  const body = sections.map((s) => `## ${s.title}\n\n${s.content}\n`).join('\n');
  const refs = evidence
    .map((e) => `[${e.n}] ${e.authors ? e.authors + '. ' : ''}${e.title}. ${e.section ? e.section + ', ' : ''}${e.year || ''}${e.page ? ', p.' + e.page : ''}`)
    .join('\n');
  return `# ${topic}\n\n> 本稿由本地知识库证据生成，每条论断后的 [n] 对应下方证据清单，请逐条核对原文后再使用。\n\n${body}\n## 证据清单\n\n${refs}\n`;
}

/**
 * 通用写作辅助：润色 / 摘要 / Related Work / 方法段落 / 审稿回复。
 */
async function writeAssist(params) {
  const { cfg, mode, text, context, lang = 'zh', usageHook, onDelta } = params;
  const tasks = {
    polish: '润色这段文字，使其符合学术汉语/学术英语规范：去掉口语化表达、增强逻辑连接、保持原意与全部数据不变。只输出润色后的文字。',
    abstract: '为以下内容撰写结构化摘要（背景/方法/结果/结论四段，共 200-300 字）。',
    relatedwork: '把这段文字改写为可直接用于学位论文/期刊的 Related Work 段落：按研究脉络组织、突出与本文的差异、保留全部引用。',
    method: '把这段文字整理为规范的 Methods 段落：明确输入输出、关键步骤与参数设置，使用被动语态与过去时。',
    rebuttal: '你是作者，正在回复审稿人。请针对审稿意见给出专业、克制、有依据的回复：先感谢，再逐条回应，每条给出修改承诺。',
  };
  const sys = SYSTEM_SURVEY;
  const user = `${tasks[mode] || tasks.polish}\n\n${context ? '补充上下文：\n' + context + '\n\n' : ''}原文：\n${text}`;
  const messages = [
    { role: 'system', content: sys },
    { role: 'user', content: user },
  ];
  if (onDelta) {
    const r = await chatStream(cfg, messages, onDelta, { temperature: 0.35 });
    usageHook?.({ usage: r.usage, feature: `write-${mode}` });
    return r.content;
  }
  const r = await chat(cfg, messages, { temperature: 0.35 });
  usageHook?.({ usage: r.usage, feature: `write-${mode}` });
  return r.content;
}

/** 研究构思：给定论文，找局限与可进攻点 */
async function discoverIdeas(params) {
  const { cfg, paper, lang = 'zh', usageHook, onDelta } = params;
  const messages = [
    { role: 'system', content: SYSTEM_SURVEY },
    { role: 'user', content: ideaPrompt(paper, lang) },
  ];
  if (onDelta) {
    const r = await chatStream(cfg, messages, onDelta, { temperature: 0.6 });
    usageHook?.({ usage: r.usage, feature: 'idea' });
    return r.content;
  }
  const r = await chat(cfg, messages, { temperature: 0.6 });
  usageHook?.({ usage: r.usage, feature: 'idea' });
  return r.content;
}

module.exports = {
  answerQuestion,
  generateSurvey,
  writeAssist,
  discoverIdeas,
  retrieveEvidences,
  buildEvidence,
  toSurveyMarkdown,
  extractJSON,
};
