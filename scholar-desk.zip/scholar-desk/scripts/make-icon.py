# -*- coding: utf-8 -*-
"""
生成 ScholarDesk 应用图标（多尺寸 .ico，含 Windows 需要的 256x256）。
设计：与界面同色系（棕 #8a5a3c），中央衬线体「研」字，圆角卡片。
"""
import os
from PIL import Image, ImageDraw, ImageFont

OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'build')
os.makedirs(OUT_DIR, exist_ok=True)

SIZES = [16, 20, 24, 32, 40, 48, 64, 96, 128, 256]
BG = (138, 90, 60, 255)        # #8a5a3c
FG = (255, 252, 248, 255)      # 字色

CANDIDATES = [
    '/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc',
    '/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc',
    '/nix/store/smgbvz9sqcikc18vf3i9ry2p5zlnb7h5-noto-fonts-cjk-sans-2.004/share/fonts/opentype/noto-cjk/NotoSansCJK-VF.otf.ttc',
    '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc',
    '/usr/share/fonts/truetype/wqy/wqy-microhei.ttc',
]


def load_font(size):
    for p in CANDIDATES:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size, index=0)
            except Exception:
                continue
    return ImageFont.load_default()


def make(size):
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    # 圆角矩形背景（小尺寸减小圆角，避免糊成一团）
    r = max(2, int(size * 0.22))
    d.rounded_rectangle([0, 0, size - 1, size - 1], radius=r, fill=BG)
    # 中央「研」字
    fs = int(size * 0.62)
    font = load_font(fs)
    txt = '研'
    bbox = d.textbbox((0, 0), txt, font=font)
    w, h = bbox[2] - bbox[0], bbox[3] - bbox[1]
    x = (size - w) / 2 - bbox[0]
    y = (size - h) / 2 - bbox[1]
    d.text((x, y), txt, font=font, fill=FG)
    return img


def main():
    imgs = [make(s) for s in SIZES]
    ico = os.path.join(OUT_DIR, 'icon.ico')
    imgs[-1].save(ico, format='ICO', sizes=[(s, s) for s in SIZES],
                  append_images=[im.resize((s, s), Image.LANCZOS) for im, s in zip(imgs[:-1], SIZES[:-1])])
    png = os.path.join(OUT_DIR, 'icon.png')
    imgs[-1].save(png, format='PNG')
    # 顺便出一张用于安装包头图的横幅
    banner = Image.new('RGBA', (164, 314), (0, 0, 0, 0))
    bd = ImageDraw.Draw(banner)
    bd.rounded_rectangle([0, 0, 163, 313], radius=14, fill=(250, 249, 247, 255))
    bd.rounded_rectangle([0, 0, 163, 313], radius=14, outline=(232, 228, 220, 255), width=1)
    logo = imgs[-1].resize((72, 72), Image.LANCZOS)
    banner.alpha_composite(logo, ((164 - 72) // 2, 40))
    f2 = load_font(22)
    bb = bd.textbbox((0, 0), 'ScholarDesk', font=f2)
    bd.text(((164 - (bb[2] - bb[0])) / 2 - bb[0], 132), 'ScholarDesk', font=f2, fill=(31, 29, 26, 255))
    f3 = load_font(15)
    for i, line in enumerate(['本地优先 · AI 科研助手']):
        bb = bd.textbbox((0, 0), line, font=f3)
        bd.text(((164 - (bb[2] - bb[0])) / 2 - bb[0], 168 + i * 24), line, font=f3, fill=(145, 138, 128, 255))
    banner.save(os.path.join(OUT_DIR, 'installerHeader.bmp').replace('.bmp', '.png'), format='PNG')
    print('ico:', ico, os.path.getsize(ico), 'bytes')
    print('png:', png, os.path.getsize(png), 'bytes')


if __name__ == '__main__':
    main()
