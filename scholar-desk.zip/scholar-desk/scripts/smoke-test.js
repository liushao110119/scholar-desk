'use strict';
/**
 * 核心逻辑自测（不需要 Electron、不需要联网）。
 * 跑法：npm test
 *
 * 覆盖：分词与 BM25、PDF 解析与结构化切分、知识库检索与出处、
 *       翻译响应解析（含脏输入）、各家检索 API 的响应解析（用 fixture + mock fetch）、
 *       模型适配层的 OpenAI 兼容调用与流式、用量统计。
 */

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');

const ROOT = path.join(__dirname, '..');
const { BM25Index, tokenize } = require(path.join(ROOT, 'src/main/bm25'));
const pdf = require(path.join(ROOT, 'src/main/pdf'));
const { Library } = require(path.join(ROOT, 'src/main/library'));
const translate = require(path.join(ROOT, 'src/main/translate'));
const usageMod = require(path.join(ROOT, 'src/main/usage'));
const search = require(path.join(ROOT, 'src/main/search'));
const providers = require(path.join(ROOT, 'src/main/providers'));
const { Store } = require(path.join(ROOT, 'src/main/store'));
const survey = require(path.join(ROOT, 'src/main/survey'));

let pass = 0;
let fail = 0;
function t(name, fn) {
  return Promise.resolve()
    .then(fn)
    .then(() => {
      pass++;
      console.log(`  ✓ ${name}`);
    })
    .catch((e) => {
      fail++;
      console.log(`  ✗ ${name}\n      ${e.message}`);
    });
}

const SAMPLE_EN = path.join(ROOT, '..', 'deps', 'sample_en.pdf');

// ---------------------------------------------------------------- fixtures

const ARXIV_XML = `<?xml version="1.0" encoding="UTF-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
  <entry>
    <id>http://arxiv.org/abs/1706.03762v1</id>
    <updated>2017-06-12T17:57:34Z</updated>
    <published>2017-06-12T17:57:34Z</published>
    <title>Attention Is All You Need
</title>
    <summary>We propose a new simple network architecture, the Transformer.</summary>
    <author><name>Ashish Vaswani</name></author>
    <author><name>Noam Shazeer</name></author>
    <link href="http://arxiv.org/abs/1706.03762v1" rel="alternate" type="text/html"/>
    <link title="pdf" href="http://arxiv.org/pdf/1706.03762v1" rel="related" type="application/pdf"/>
  </entry>
</feed>`;

const OPENALEX_JSON = {
  results: [
    {
      id: 'https://openalex.org/W1',
      doi: 'https://doi.org/10.1000/xyz',
      title: 'Medical Image Segmentation with Transformers',
      publication_year: 2021,
      cited_by_count: 120,
      authorships: [{ author: { display_name: 'Jieneng Chen' } }],
      primary_location: { source: { display_name: 'Medical Image Analysis' } },
      abstract_inverted_index: { Hybrid: [0], CNN: [1], transformer: [2], architectures: [3] },
      open_access: { oa_url: 'https://example.com/a.pdf' },
    },
  ],
};

const CROSSREF_JSON = {
  message: {
    items: [
      {
        DOI: '10.1000/xyz',
        title: ['Medical Image Segmentation with Transformers'],
        author: [{ given: 'Jieneng', family: 'Chen' }],
        'container-title': ['Medical Image Analysis'],
        issued: { 'date-parts': [[2021]] },
        'is-referenced-by-count': 130,
        URL: 'https://doi.org/10.1000/xyz',
      },
    ],
  },
};

const S2_JSON = {
  data: [
    {
      paperId: 'abc123',
      title: 'U-Net: Convolutional Networks for Biomedical Image Segmentation',
      abstract: 'There is large consent that successful training of deep networks requires many thousand annotated training samples.',
      year: 2015,
      venue: 'MICCAI',
      authors: [{ name: 'Olaf Ronneberger' }],
      citationCount: 40000,
      externalIds: { DOI: '10.1007/978-3-319-24574-4_28' },
      url: 'https://www.semanticscholar.org/paper/abc123',
      openAccessPdf: { url: 'https://example.com/unet.pdf' },
    },
  ],
};

/** 按 URL 分发的 mock fetch */
function mockFetch(routes) {
  const realFetch = global.fetch;
  global.fetch = async (url, opts) => {
    for (const [pattern, handler] of routes) {
      if (String(url).includes(pattern)) return handler(url, opts);
    }
    const e = new Error('unmocked url: ' + url);
    e.name = 'TypeError';
    throw e;
  };
  return () => {
    global.fetch = realFetch;
  };
}

function jsonResponse(obj) {
  return {
    ok: true,
    status: 200,
    json: async () => obj,
    text: async () => JSON.stringify(obj),
  };
}

function xmlResponse(text) {
  return { ok: true, status: 200, text: async () => text, json: async () => JSON.parse(text) };
}

/** 模拟 SSE 流式响应（每次 getReader 都新建一条流，避免 locked） */
function sseResponse(chunks) {
  const enc = new TextEncoder();
  return {
    ok: true,
    status: 200,
    body: {
      getReader() {
        const stream = new ReadableStream({
          start(controller) {
            for (const c of chunks) controller.enqueue(enc.encode(c));
            controller.close();
          },
        });
        return stream.getReader();
      },
    },
  };
}

// ---------------------------------------------------------------- tests

(async () => {
  console.log('\n[1] 分词与检索索引');
  await t('中英混排分词：中文 bigram + 英文单词', () => {
    const toks = tokenize('医学图像分割 Medical Image Segmentation Dice 77.48%');
    assert.ok(toks.includes('医学'), '缺少中文 bigram');
    assert.ok(toks.includes('segmentation'), '缺少英文词');
    assert.ok(toks.some((x) => x.includes('77')), '缺少数字');
  });

  await t('BM25 能按相关性排序并返回正确文档', () => {
    const idx = new BM25Index();
    idx.add('d1', 'TransUNet achieves an average Dice score of 77.48 percent on Synapse dataset');
    idx.add('d2', 'The Transformer architecture uses self-attention for sequence modeling');
    idx.add('d3', 'We train all models on a single RTX 3090 GPU for 300 epochs');
    const hits = idx.search('Dice score on Synapse', 3);
    assert.strictEqual(hits[0].id, 'd1', `期望 d1 排在首位，实际 ${hits[0].id}`);
    const hits2 = idx.search('GPU epochs training', 3);
    assert.strictEqual(hits2[0].id, 'd3');
  });

  await t('BM25 支持限定文档子集检索', () => {
    const idx = new BM25Index();
    idx.add('a', 'transformer segmentation');
    idx.add('b', 'transformer segmentation');
    const hits = idx.search('segmentation', 5, new Set(['b']));
    assert.deepStrictEqual(hits.map((h) => h.id), ['b']);
  });

  await t('索引可持久化并还原', () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bm25-'));
    const f = path.join(dir, 'i.json');
    const idx = new BM25Index();
    idx.add('x', 'graph neural network for protein prediction');
    idx.save(f);
    const loaded = BM25Index.load(f);
    assert.strictEqual(loaded.search('protein prediction', 1)[0].id, 'x');
  });

  console.log('\n[2] PDF 解析与学术结构切分');
  if (!fs.existsSync(SAMPLE_EN)) {
    console.log('  ! 跳过：未找到测试样张 sample_en.pdf');
  } else {
    let parsed;
    await t('解析真实 PDF：拿到标题/年份/页数', async () => {
      parsed = await pdf.parsePdfFile(SAMPLE_EN);
      assert.ok(parsed.numpages >= 1, '页数异常');
      assert.ok(parsed.segments.length >= 5, `段落数偏少：${parsed.segments.length}`);
      assert.ok(parsed.chunks.length >= 3, 'chunk 数偏少');
    });

    await t('章节标题被正确识别（1 Introduction / 2 Methods / 3 Results / References）', () => {
      const heads = parsed.segments.filter((s) => s.kind === 'heading').map((s) => s.text);
      assert.ok(heads.some((h) => /Introduction/i.test(h)), `未识别 Introduction：${heads}`);
      assert.ok(heads.some((h) => /Methods/i.test(h)), `未识别 Methods：${heads}`);
      assert.ok(heads.some((h) => /Results/i.test(h)), `未识别 Results：${heads}`);
      assert.ok(heads.some((h) => /References/i.test(h)), `未识别 References：${heads}`);
    });

    await t('段落归属到正确章节', () => {
      const intro = parsed.segments.find((s) => s.kind === 'paragraph' && /Introduction/i.test(s.section));
      assert.ok(intro, '没有归属到 Introduction 的段落');
      assert.ok(/computer-aided diagnosis/.test(intro.text), '引言段落内容不对');
      const res = parsed.segments.find((s) => s.kind === 'paragraph' && /Results/i.test(s.section));
      assert.ok(res && /Dice/.test(res.text), '结果段落应包含 Dice 指标');
    });

    await t('公式行会被标记（不参与翻译）', () => {
      const lines = [{ text: 'L = α · L_dice + β · L_ce,  α = 0.7', y: 100 }];
      const built = pdf.buildLinesFromItems(
        lines.map((l) => ({ str: l.text, transform: [1, 0, 0, 1, 50, l.y] }))
      );
      assert.ok(built.length === 1);
      assert.ok(pdf.looksFormula('L = α · L_dice + β · L_ce'), '公式未被识别');
      assert.ok(!pdf.looksFormula('We evaluate on the Synapse dataset.'), '普通句子被误判为公式');
    });
  }

  console.log('\n[3] 知识库：入库、检索、出处');
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'sd-'));
  await t('导入文本后可按语义检索并带出章节与页码', async () => {
    const lib = new Library(tmp);
    const doc = lib.addText({
      title: '医学图像分割综述',
      authors: '张三, 李四',
      year: 2024,
      text: [
        '1 引言',
        '医学图像分割是计算机辅助诊断的基础任务，标注样本少、模态差异大。',
        '2 方法',
        '现有方法分为纯卷积架构、纯 Transformer 架构与混合架构三类。',
        '3 结果',
        '在 Synapse 数据集上，TransUNet 的平均 Dice 系数为 77.48%，Swin-UNet 为 79.13%。',
      ].join('\n'),
    });
    assert.strictEqual(doc.chunkCount > 0, true, '未生成 chunk');
    const hits = await lib.search('Dice 系数 在 Synapse 上谁更高', 5);
    assert.ok(hits.length, '没检索到结果');
    assert.ok(/Dice/.test(hits[0].text), `首位结果不含 Dice：${hits[0].text.slice(0, 60)}`);
    assert.strictEqual(hits[0].title, '医学图像分割综述');
    assert.ok(hits[0].section, '缺少章节信息');
    assert.ok(hits[0].page >= 1, '缺少页码');
  });

  await t('限定单篇文献检索', async () => {
    const lib = new Library(path.join(tmp, 'lib2'));
    lib.addText({ title: 'A', text: 'graph neural networks for molecules' });
    const b = lib.addText({ title: 'B', text: 'transformer for medical image segmentation' });
    const hits = await lib.search('segmentation transformer', 5, { docIds: [b.id] });
    assert.ok(hits.length && hits.every((h) => h.docId === b.id), '检索结果越界到其他文献');
  });

  await t('删除文献后不再被检索到', async () => {
    const lib = new Library(path.join(tmp, 'lib3'));
    const d = lib.addText({ title: '待删除', text: 'unique content about federated learning' });
    lib.remove(d.id);
    const hits = await lib.search('federated learning', 5);
    assert.strictEqual(hits.length, 0, '删除后仍能检索到');
  });

  console.log('\n[4] 翻译：响应解析与分批');
  await t('解析干净的 JSON 响应', () => {
    const raw = '{"items":[{"i":1,"t":"译文一"},{"i":2,"t":"译文二"}],"glossary":{"transformer":"Transformer"}}';
    const r = translate.parseTranslationResponse(raw);
    assert.strictEqual(r.map.get(1), '译文一');
    assert.strictEqual(r.map.get(2), '译文二');
    assert.strictEqual(r.glossary.transformer, 'Transformer');
  });

  await t('解析带 markdown 围栏与前后废话的脏响应', () => {
    const raw = '好的，如下：\n```json\n{"items":[{"i":1,"t":"含公式 $E=mc^2$ 的译文"}]}\n```\n希望对你有帮助';
    const r = translate.parseTranslationResponse(raw);
    assert.strictEqual(r.map.get(1), '含公式 $E=mc^2$ 的译文');
  });

  await t('JSON 损坏时回退到行号解析', () => {
    const raw = '1. 第一段译文\n2. 第二段译文\n3. 第三段译文';
    const r = translate.parseTranslationResponse(raw);
    assert.strictEqual(r.map.get(2), '第二段译文', '行号兜底失败');
  });

  await t('分批不切断段落且不超过字符上限', () => {
    const items = [{ text: 'A'.repeat(700) }, { text: 'B'.repeat(700) }, { text: 'C'.repeat(100) }];
    const batches = translate.makeBatches(items, 1000);
    // 700 单独一批；700+100 凑一批 —— 不切断段落，也不超过上限
    assert.strictEqual(batches.length, 2, `批次划分错误：${batches.length}`);
    assert.strictEqual(batches[0][0].text.length, 700, '段落被切断');
    for (const b of batches) {
      const size = b.reduce((n, x) => n + x.text.length, 0);
      assert.ok(size <= 1000 || b.length === 1, `批次超限：${size}`);
    }
    // 全部段落不丢不重
    assert.strictEqual(batches.flat().length, 3);
  });

  await t('对照导出：Markdown 与 HTML', () => {
    const segs = [
      { kind: 'paragraph', page: 1, section: '1 引言', text: 'We study <segmentation>.', translated: '我们研究<分割>。' },
    ];
    const md = translate.toBilingualMarkdown(segs, { title: 'T', authors: 'A', year: 2024 });
    assert.ok(md.includes('我们研究'), 'Markdown 缺少译文');
    const html = translate.toBilingualHTML(segs, { title: 'T' });
    assert.ok(html.includes('&lt;segmentation&gt;'), 'HTML 未转义尖括号');
    assert.ok(html.includes('我们研究'), 'HTML 缺少译文');
  });

  console.log('\n[5] 学术检索：响应解析与去重导出（mock fetch）');
  const restore1 = mockFetch([
    ['export.arxiv.org', async () => xmlResponse(ARXIV_XML)],
    ['api.openalex.org', async () => jsonResponse(OPENALEX_JSON)],
    ['api.crossref.org', async () => jsonResponse(CROSSREF_JSON)],
    ['api.semanticscholar.org', async () => jsonResponse(S2_JSON)],
  ]);

  await t('arXiv Atom XML 解析出标题/作者/年份/PDF 链接', async () => {
    const items = await search.searchArxiv('transformer', { limit: 5 });
    assert.strictEqual(items.length, 1);
    assert.strictEqual(items[0].title, 'Attention Is All You Need');
    assert.deepStrictEqual(items[0].authors, ['Ashish Vaswani', 'Noam Shazeer']);
    assert.strictEqual(items[0].year, 2017);
    assert.ok(items[0].pdfUrl.includes('pdf'), '缺少 PDF 链接');
  });

  await t('OpenAlex 摘要倒排索引可还原', async () => {
    const items = await search.searchOpenAlex('segmentation', { limit: 5 });
    assert.ok(/Hybrid CNN transformer architectures/.test(items[0].abstract), `摘要还原失败：${items[0].abstract}`);
    assert.strictEqual(items[0].citationCount, 120);
  });

  await t('Crossref 解析 DOI/期刊/被引', async () => {
    const items = await search.searchCrossref('segmentation');
    assert.strictEqual(items[0].doi, '10.1000/xyz');
    assert.strictEqual(items[0].venue, 'Medical Image Analysis');
    assert.strictEqual(items[0].year, 2021);
  });

  await t('Semantic Scholar 解析摘要与 PDF', async () => {
    const items = await search.searchSemanticScholar('u-net');
    assert.ok(items[0].abstract.includes('annotated'));
    assert.strictEqual(items[0].pdfUrl, 'https://example.com/unet.pdf');
  });

  await t('跨源按 DOI 去重（OpenAlex 与 Crossref 同一篇只留一条）', async () => {
    const { items } = await search.searchAll('medical image segmentation', { sources: ['openalex', 'crossref'] });
    const same = items.filter((p) => p.doi === '10.1000/xyz');
    assert.strictEqual(same.length, 1, `去重失败，出现 ${same.length} 次`);
    assert.ok(same[0].sources.length >= 2, '未记录多来源');
  });

  await t('聚合检索：单源失败不影响其他源', async () => {
    const restore = mockFetch([
      ['export.arxiv.org', async () => xmlResponse(ARXIV_XML)],
      ['api.openalex.org', async () => jsonResponse(OPENALEX_JSON)],
      ['api.crossref.org', async () => { throw new Error('boom'); }],
    ]);
    const { items, errors } = await search.searchAll('transformer', { sources: ['arxiv', 'openalex', 'crossref'] });
    assert.ok(items.length >= 2, '失败的源不该影响其他源');
    assert.ok(errors.some((e) => e.source === 'crossref'), '未记录失败源');
    restore();
  });

  await t('导出 BibTeX 与 GB/T 7714', () => {
    const items = [
      {
        title: 'Medical Image Segmentation with Transformers',
        authors: ['Jieneng Chen', 'Yongyi Lu', 'Qihang Yu', 'Extra Author'],
        year: 2021,
        venue: 'Medical Image Analysis',
        doi: '10.1000/xyz',
        citations: 120,
        sources: ['openalex'],
      },
    ];
    const bib = search.toBibTeX(items);
    assert.ok(bib.includes('@article{'), 'BibTeX 类型不对');
    assert.ok(bib.includes('and Extra Author'), 'BibTeX 作者未用 and 连接');
    const gb = search.toGB7714(items);
    assert.ok(gb.startsWith('[1]'), 'GB/T 7714 缺少序号');
    assert.ok(gb.includes('等') || gb.includes('et al.'), 'GB/T 7714 未处理多作者');
    assert.ok(gb.includes('DOI:10.1000/xyz'), 'GB/T 7714 缺少 DOI');
  });
  restore1();

  console.log('\n[6] 模型适配层（OpenAI 兼容协议，mock fetch）');
  await t('补全 baseUrl 到 /v1 形式', () => {
    assert.strictEqual(providers.normalizeBaseUrl('https://api.deepseek.com'), 'https://api.deepseek.com/v1');
    assert.strictEqual(providers.normalizeBaseUrl('https://api.deepseek.com/v1/'), 'https://api.deepseek.com/v1');
    assert.strictEqual(providers.normalizeBaseUrl('http://localhost:11434/v1'), 'http://localhost:11434/v1');
  });

  await t('非流式对话返回内容与 usage', async () => {
    const restore = mockFetch([
      [
        'chat/completions',
        async () =>
          jsonResponse({
            choices: [{ message: { content: '这是回答' } }],
            usage: { prompt_tokens: 100, completion_tokens: 50 },
          }),
      ],
    ]);
    const r = await providers.chat(
      { baseUrl: 'https://api.example.com/v1', apiKey: 'k', model: 'm' },
      [{ role: 'user', content: 'hi' }]
    );
    assert.strictEqual(r.content, '这是回答');
    assert.strictEqual(r.usage.prompt_tokens, 100);
    restore();
  });

  await t('流式对话按 SSE 逐段拼接', async () => {
    const restore = mockFetch([
      [
        'chat/completions',
        async () =>
          sseResponse([
            'data: {"choices":[{"delta":{"content":"第一段"}}]}\n\n',
            'data: {"choices":[{"delta":{"content":"第二段"}}]}\n\n',
            'data: [DONE]\n\n',
          ]),
      ],
    ]);
    const got = [];
    const r = await providers.chatStream(
      { baseUrl: 'https://api.example.com/v1', apiKey: 'k', model: 'm' },
      [{ role: 'user', content: 'hi' }],
      (d) => got.push(d)
    );
    assert.strictEqual(r.content, '第一段第二段');
    assert.deepStrictEqual(got, ['第一段', '第二段']);
    restore();
  });

  await t('HTTP 401 给出可读的中文提示', async () => {
    const restore = mockFetch([
      ['chat/completions', async () => ({ ok: false, status: 401, text: async () => '{"error":"invalid key"}' })],
    ]);
    await assert.rejects(
      () => providers.chat({ baseUrl: 'https://x/v1', apiKey: 'bad', model: 'm' }, [{ role: 'user', content: 'hi' }]),
      /401/
    );
    restore();
  });

  await t('未配置 baseUrl / model 时提前报错，不发请求', async () => {
    await assert.rejects(() => providers.chat({ baseUrl: '', apiKey: 'k', model: 'm' }, []), /API 地址/);
    await assert.rejects(() => providers.chat({ baseUrl: 'https://x/v1', apiKey: 'k', model: '' }, []), /模型名/);
  });

  await t('预设供应商覆盖主流家且价格可改', () => {
    const ids = Object.keys(providers.PRESETS);
    for (const need of ['deepseek', 'dashscope', 'moonshot', 'zhipu', 'siliconflow', 'openai', 'ollama', 'custom']) {
      assert.ok(ids.includes(need), `缺少预设：${need}`);
    }
    assert.strictEqual(providers.PRESETS.ollama.price.in, 0, '本地模型应为 0 成本');
  });

  console.log('\n[7] 用量统计与配置存储');
  await t('按供应商价格表折算成本', () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'usage-'));
    const u = new usageMod.Usage(dir);
    u.record({ provider: 'deepseek', model: 'deepseek-chat', feature: 'qa', usage: { prompt_tokens: 1000000, completion_tokens: 200000 }, pricePerMTok: { in: 2, out: 8 } });
    const s = u.summary();
    assert.strictEqual(s.totalCostYuan, 3.6, `成本计算错误：${s.totalCostYuan}`);
    assert.strictEqual(s.calls, 1);
    assert.ok(s.byFeature.qa === 3.6);
  });

  await t('配置与 Key 落盘（非 Electron 下明文降级）', () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'store-'));
    const st = new Store(dir);
    st.setProviderOptions('deepseek', { apiKey: 'sk-test-123', model: 'deepseek-chat' });
    st.set('provider', 'deepseek');
    const st2 = new Store(dir);
    assert.strictEqual(st2.getApiKey('deepseek'), 'sk-test-123', 'Key 未持久化');
    assert.strictEqual(st2.get('provider'), 'deepseek');
    const cfg = st2.getProviderConfig('deepseek');
    assert.strictEqual(cfg.model, 'deepseek-chat');
    assert.ok(cfg.baseUrl.includes('deepseek'), '未带出预设 baseUrl');
  });

  console.log('\n[8] 综述：证据锚点与大纲兜底');
  await t('证据编号与原文一一对应', async () => {
    const lib = new Library(path.join(tmp, 'lib4'));
    lib.addText({ title: '证据文献', year: 2023, text: '混合架构在 ACDC 数据集上达到 91.25% 的 Dice 系数，优于纯卷积方法。\n训练使用单卡 RTX 3090，300 轮。' });
    const hits = await lib.search('Dice 系数 ACDC', 5);
    const ev = survey.buildEvidence(hits);
    assert.ok(ev.length && ev[0].n === 1);
    assert.ok(ev[0].excerpt.includes('Dice'), '证据摘要不含关键内容');
  });

  await t('大纲 JSON 解析失败时使用默认结构兜底', () => {
    assert.strictEqual(survey.extractJSON('这不是 JSON'), null);
    assert.ok(survey.extractJSON('```json\n{"sections":[{"title":"1 引言"}]}\n```').sections.length === 1);
  });

  await t('综述 Markdown 含证据清单', () => {
    const md = survey.toSurveyMarkdown(
      '测试主题',
      [{ title: '1 引言', content: '正文[1]' }],
      [{ n: 1, title: '证据文献', year: 2023, section: '结果', page: 2, authors: '张三' }]
    );
    assert.ok(md.includes('# 测试主题'));
    assert.ok(md.includes('证据清单'));
    assert.ok(md.includes('[1] 张三'), '证据清单缺少作者与编号');
  });

  console.log(`\n结果：${pass} 通过 / ${fail} 失败\n`);
  process.exit(fail ? 1 : 0);
})();
