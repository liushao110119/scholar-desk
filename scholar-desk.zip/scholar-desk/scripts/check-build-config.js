'use strict';
/**
 * 打包前静态自检：确认 electron-builder 的配置与引用文件都到位。
 * 在 npm install 之后、electron-builder 之前跑，避免打完包才发现图标或入口缺失。
 *
 *   node scripts/check-build-config.js
 */

const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
let pass = 0;
let fail = 0;

function ok(cond, name, detail) {
  if (cond) {
    pass++;
    console.log(`  ✓ ${name}`);
  } else {
    fail++;
    console.log(`  ✗ ${name}${detail ? '\n      ' + detail : ''}`);
  }
}

const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));

console.log('\n[打包配置自检]');

// 1. 入口
ok(fs.existsSync(path.join(ROOT, pkg.main)), `主进程入口存在：${pkg.main}`, 'package.json 的 main 指向的文件不存在');
ok(fs.existsSync(path.join(ROOT, 'src/preload.js')), 'preload.js 存在');
ok(fs.existsSync(path.join(ROOT, 'src/renderer/index.html')), '界面 index.html 存在');
ok(fs.existsSync(path.join(ROOT, 'src/renderer/style.css')), 'style.css 存在');
ok(fs.existsSync(path.join(ROOT, 'src/renderer/app.js')), 'app.js 存在');

// 2. 图标
const icon = pkg.build && pkg.build.icon;
ok(!!icon, '已声明应用图标');
if (icon) {
  const p = path.join(ROOT, icon);
  ok(fs.existsSync(p), `图标文件存在：${icon}`, '缺少图标，Windows exe 会用 Electron 默认图标');
  if (fs.existsSync(p) && icon.endsWith('.ico')) {
    const buf = fs.readFileSync(p);
    // ICO 头：保留字 0、类型 1、图像数量
    const count = buf.readUInt16LE(4);
    ok(buf.readUInt16LE(0) === 0 && buf.readUInt16LE(2) === 1, 'ICO 文件头合法');
    ok(count >= 5, `ICO 含 ${count} 个尺寸（建议 ≥5，含 256x256）`);
    let has256 = false;
    for (let i = 0; i < count; i++) {
      const o = 6 + i * 16;
      const w = buf[o] === 0 ? 256 : buf[o];
      if (w >= 256) has256 = true;
    }
    ok(has256, 'ICO 含 256x256（Windows 任务栏大图标需要）');
  }
}

// 3. Windows 目标
const win = pkg.build && pkg.build.win;
ok(!!win, '已配置 win 打包目标');
if (win) {
  const targets = (win.target || []).map((t) => (typeof t === 'string' ? t : t.target));
  ok(targets.includes('nsis'), '含 NSIS 安装版');
  ok(targets.includes('portable'), '含 portable 免安装版');
  ok(!!win.icon && fs.existsSync(path.join(ROOT, win.icon)), 'win 图标存在');
}

// 4. NSIS 细节
const nsis = pkg.build && pkg.build.nsis;
if (nsis) {
  ok(nsis.oneClick === false, '安装程序允许选择安装目录（非一键安装）');
  ok(!!nsis.shortcutName, '设置了快捷方式名称');
  if (nsis.installerHeader) {
    ok(fs.existsSync(path.join(ROOT, nsis.installerHeader)), `安装向导头图存在：${nsis.installerHeader}`);
  }
  if (Array.isArray(nsis.installerLanguages)) {
    ok(nsis.installerLanguages.includes('zh_CN'), '安装界面含简体中文');
  }
}

// 5. 依赖
ok(!!(pkg.dependencies || {})['pdfjs-dist'], 'PDF 主引擎 pdfjs-dist 在 dependencies 中');
ok(!!(pkg.devDependencies || {}).electron, 'electron 在 devDependencies 中');
ok(!!(pkg.devDependencies || {})['electron-builder'], 'electron-builder 在 devDependencies 中');

// 6. 依赖是否已安装
ok(fs.existsSync(path.join(ROOT, 'node_modules')), 'node_modules 已安装（没装请先 npm install）');

// 7. asar 决策
ok(
  pkg.build.asar === false,
  'asar 已关闭（原因见下）',
  'pdfjs-dist 是 ESM，动态 import 在 asar 内会失败，必须关闭 asar'
);

// 8. files 覆盖
const files = (pkg.build && pkg.build.files) || [];
ok(files.some((f) => f.includes('src/**')), 'files 包含 src 目录');

// 9. 构建脚本
ok(fs.existsSync(path.join(ROOT, 'build-windows.bat')), '一键构建脚本 build-windows.bat 存在');
ok(fs.existsSync(path.join(ROOT, '.github/workflows/build-windows.yml')), 'GitHub Actions 工作流存在');

console.log(`\n结果：${pass} 通过 / ${fail} 失败`);
if (fail) {
  console.log('\n提示：asar 必须为 false —— pdfjs-dist 通过动态 import() 加载 .mjs，');
  console.log('      Node 的 ESM loader 不识别 asar 协议，打包进 asar 会导致 PDF 解析直接报 "找不到模块"。');
}
process.exit(fail ? 1 : 0);
